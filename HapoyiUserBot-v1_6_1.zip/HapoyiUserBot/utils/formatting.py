from __future__ import annotations

import html
import re
from datetime import datetime, timezone


def clean_text(text: str, limit: int = 3500) -> str:
    text = text or ""
    return text if len(text) <= limit else text[: limit - 3] + "..."


def esc(text: object) -> str:
    return html.escape(str(text))


def fmt_money(value: float, decimals: int = 2) -> str:
    return f"{value:,.{decimals}f}"


def utc_iso(dt: datetime | None = None) -> str:
    return (dt or datetime.now(timezone.utc)).isoformat(timespec="seconds")


def parse_duration(raw: str) -> int:
    m = re.fullmatch(r"(?i)(\d+(?:\.\d+)?)(s|m|h|d|w)", raw.strip())
    if not m:
        raise ValueError("مدت باید مثل 30s، 5m، 2h یا 1d باشد")
    value = float(m.group(1))
    mult = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[m.group(2).lower()]
    seconds = int(value * mult)
    if seconds < 1 or seconds > 365 * 86400:
        raise ValueError("مدت خارج از محدوده است")
    return seconds
