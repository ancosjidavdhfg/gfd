from __future__ import annotations

from typing import Any

from core.permissions import resolve_target


async def target_from_event(event: Any, args: list[str]) -> Any:
    explicit = args[0] if args else None
    return await resolve_target(event, explicit)


def target_label(target: Any) -> str:
    if target is None:
        return "نامشخص"
    username = getattr(target, "username", None)
    if username:
        return f"@{username}"
    name = " ".join(x for x in [getattr(target, "first_name", ""), getattr(target, "last_name", "")] if x).strip()
    return name or str(getattr(target, "id", target))
