from __future__ import annotations

import re
import time
from collections import defaultdict, deque
from dataclasses import dataclass

# Detect common Telegram/web links without treating ordinary punctuation as links.
URL_RE = re.compile(
    r"(?ix)(?:"
    r"https?://[^\s<>]+|"
    r"www\.[^\s<>]+|"
    r"(?:t\.me|telegram\.me|telegram\.dog)/[^\s<>]+|"
    r"tg://[^\s<>]+"
    r")"
)
INVITE_RE = re.compile(r"(?ix)(?:https?://)?(?:t\.me|telegram\.me)/(?:\+|joinchat/|c/)[^\s<>]+")

@dataclass(frozen=True)
class Violation:
    chat_id: int
    user_id: int
    now: float
    count: int

class LinkCounter:
    """Per chat/user rolling-window link counter; intentionally in-memory."""
    def __init__(self, maxlen: int = 200):
        self._events: dict[tuple[int, int], deque[float]] = defaultdict(lambda: deque(maxlen=maxlen))

    def add(self, chat_id: int, user_id: int, window: int) -> Violation:
        now = time.monotonic()
        q = self._events[(int(chat_id), int(user_id))]
        q.append(now)
        while q and now - q[0] > max(1, int(window)):
            q.popleft()
        return Violation(int(chat_id), int(user_id), now, len(q))

    def reset(self, chat_id: int, user_id: int) -> None:
        self._events.pop((int(chat_id), int(user_id)), None)

    def reset_chat(self, chat_id: int) -> None:
        cid = int(chat_id)
        for key in [k for k in self._events if k[0] == cid]:
            self._events.pop(key, None)


def contains_link(text: str, mode: str = "all") -> bool:
    if not text:
        return False
    if mode == "invite":
        return bool(INVITE_RE.search(text))
    return bool(URL_RE.search(text))
