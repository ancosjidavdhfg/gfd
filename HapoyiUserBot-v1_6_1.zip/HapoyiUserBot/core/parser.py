from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Command:
    name: str
    args: list[str]
    raw: str


class CommandParser:
    def __init__(self, prefix: str = "."):
        self.prefix = prefix

    def parse(self, text: str) -> Command | None:
        if not text.startswith(self.prefix):
            return None
        body = text[len(self.prefix):].strip()
        if not body:
            return None
        parts = body.split()
        return Command(parts[0].lower(), parts[1:], body)
