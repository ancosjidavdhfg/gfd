from __future__ import annotations

from dataclasses import dataclass

from .database import Database
from .runtime import Runtime


@dataclass
class Services:
    db: Database
    runtime: Runtime
