from __future__ import annotations

import logging
from telethon import events
from dotenv import load_dotenv

from config import Settings
from core.client import build_client
from core.database import Database
from core.guard import install_handler_guard
from core.logging_setup import setup_logging
from core.registry import ModuleRegistry
from core.runtime import Runtime
from core.services import Services

log = logging.getLogger(__name__)


async def start() -> None:
    load_dotenv()
    settings = Settings.from_env()
    setup_logging(settings.log_level)
    errors = settings.validate()
    if errors:
        raise SystemExit("Configuration errors:\n- " + "\n- ".join(errors))

    db = Database(__import__("config").DB_PATH)
    await db.connect()
    runtime = Runtime()
    services = Services(db, runtime)
    client = build_client(settings)
    install_handler_guard(client)

    registry = ModuleRegistry(client, db)
    client._hapoyi_registry = registry
    await registry.load_all("modules")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.health$"))
    async def health(event):
        await event.reply(
            "🟢 Hāpoyi UserBot\n"
            f"{registry.summary()}\n"
            "database=ok\n"
            "telethon=1.45.x"
        )

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.modules$"))
    async def modules(event):
        lines = ["🧩 Modules"]
        for name, info in sorted(registry.modules.items()):
            status = "✅" if info.loaded else "❌"
            lines.append(f"{status} {name}")
        await event.reply("\n".join(lines)[:4000])

    await client.start()
    me = await client.get_me()
    log.info("Logged in as %s (%s)", getattr(me, "username", None) or getattr(me, "first_name", "user"), me.id)
    log.info(registry.summary())
    try:
        await client.run_until_disconnected()
    finally:
        await runtime.shutdown()
        await db.close()
