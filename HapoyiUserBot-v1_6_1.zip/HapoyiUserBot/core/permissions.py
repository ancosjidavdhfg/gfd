from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass
from typing import Any

from telethon import errors
from telethon.errors import RPCError
from telethon.tl.types import PeerUser

from core.identity import my_id

log = logging.getLogger(__name__)

_PERM_TTL = 30.0
_ADMIN_TTL = 60.0
_perm_cache: dict[int, tuple[float, Any]] = {}
_admin_cache: dict[tuple[int, int], tuple[float, bool]] = {}


@dataclass(frozen=True)
class PermissionResult:
    allowed: bool
    reason: str = ""


RIGHT_LABELS = {
    "ban_users": "Ban Users",
    "delete_messages": "Delete Messages",
    "pin_messages": "Pin Messages",
    "invite_users": "Invite Users",
    "change_info": "Change Group Info",
}


def explain_error(exc: BaseException) -> str:
    """Human readable (Persian) reason for a Telegram/Telethon failure."""
    if isinstance(exc, errors.FloodWaitError):
        return f"تلگرام محدودیت سرعت اعمال کرد؛ {getattr(exc, 'seconds', '?')} ثانیه صبر کن."
    table = {
        "ChatAdminRequiredError": "ادمین نیستی یا دسترسی لازم را نداری.",
        "ChatWriteForbiddenError": "اجازهٔ ارسال پیام در این چت را نداری.",
        "UserAdminInvalidError": "نمی‌توانی روی ادمینی که خودت منصوبش نکردی عملیات انجام بدهی.",
        "UserCreatorError": "مالک گروه قابل تغییر نیست.",
        "UserNotParticipantError": "این کاربر عضو گروه نیست.",
        "UserIdInvalidError": "کاربر نامعتبر است.",
        "ParticipantIdInvalidError": "کاربر نامعتبر است.",
        "PeerIdInvalidError": "چت یا کاربر نامعتبر است.",
        "ChannelPrivateError": "به این چت دسترسی نداری.",
        "ChannelInvalidError": "این چت از این عملیات پشتیبانی نمی‌کند.",
        "MessageDeleteForbiddenError": "اجازهٔ حذف این پیام را نداری.",
        "MessageIdInvalidError": "پیام نامعتبر است.",
        "BotsTooMuchError": "تعداد ربات‌ها در گروه به حد مجاز رسیده است.",
        "UsernameNotOccupiedError": "این username وجود ندارد.",
        "UsernameInvalidError": "username نامعتبر است.",
    }
    name = exc.__class__.__name__
    if name in table:
        return table[name]
    text = str(exc).strip()
    return f"{name}" + (f": {text[:120]}" if text and not isinstance(exc, RPCError) else "")


async def actor_permissions(client: Any, chat_id: int, *, fresh: bool = True) -> Any:
    now = time.monotonic()
    if not fresh:
        hit = _perm_cache.get(chat_id)
        if hit and now - hit[0] < _PERM_TTL:
            return hit[1]
    try:
        perm = await client.get_permissions(chat_id, "me")
    except Exception as exc:  # noqa: BLE001 - we only need a yes/no
        log.debug("actor permission lookup failed: %s", exc)
        return None
    _perm_cache[chat_id] = (now, perm)
    return perm


def has_rights(permission: Any, *names: str) -> bool:
    """True when `permission` (Telethon ParticipantPermissions) grants every right in `names`."""
    if permission is None:
        return False
    if getattr(permission, "is_creator", False):
        return True
    if not getattr(permission, "is_admin", False):
        return False
    # NOTE: ParticipantPermissions exposes each right as a property (ban_users, ...);
    # it has NO `admin_rights` attribute, so we must read the properties directly.
    return all(bool(getattr(permission, n, False)) for n in names)


async def require_group_right(client: Any, chat_id: int, right: str, *, fresh: bool = True) -> PermissionResult:
    perm = await actor_permissions(client, chat_id, fresh=fresh)
    if perm is None:
        return PermissionResult(False, "نتوانستم دسترسی‌های تو را در این چت بررسی کنم.")
    if getattr(perm, "is_creator", False):
        return PermissionResult(True)
    if not getattr(perm, "is_admin", False):
        return PermissionResult(False, "در این گروه ادمین نیستی.")
    if not has_rights(perm, right):
        return PermissionResult(False, f"دسترسی {RIGHT_LABELS.get(right, right)} را نداری.")
    return PermissionResult(True)


async def get_real_reply(event: Any) -> Any:
    """Reply target, ignoring the implicit 'reply to topic root' of forum groups."""
    if not getattr(event, "is_reply", False):
        return None
    rt = getattr(event.message, "reply_to", None)
    if rt is not None and getattr(rt, "forum_topic", False) and not getattr(rt, "reply_to_top_id", None):
        return None
    try:
        return await event.get_reply_message()
    except Exception:  # noqa: BLE001
        return None


async def resolve_target(event: Any, explicit: str | None = None) -> Any:
    """Resolve the command target to a Telethon entity, or None. Never raises."""
    client = event.client
    if explicit:
        raw = explicit.strip()
        try:
            if re.fullmatch(r"-?\d+", raw):
                return await client.get_entity(PeerUser(int(raw)) if int(raw) > 0 else int(raw))
            return await client.get_entity(raw)
        except Exception as exc:  # noqa: BLE001
            log.debug("resolve_target(%r) failed: %s", raw, exc)
            return None
    reply = await get_real_reply(event)
    if reply is None:
        return None
    try:
        sender = await reply.get_sender()
    except Exception:  # noqa: BLE001
        sender = None
    if sender is None and reply.sender_id:
        try:
            sender = await client.get_entity(PeerUser(int(reply.sender_id)))
        except Exception:  # noqa: BLE001
            sender = None
    return sender


async def ensure_target_not_self(client: Any, target: Any) -> PermissionResult:
    target_id = getattr(target, "id", target)
    if int(target_id) == await my_id(client):
        return PermissionResult(False, "نمی‌توانم خودت را هدف این عملیات قرار بدهم.")
    return PermissionResult(True)


async def target_is_admin(client: Any, chat_id: int, target: Any, *, fresh: bool = True) -> bool:
    target_id = int(getattr(target, "id", target))
    key = (chat_id, target_id)
    now = time.monotonic()
    if not fresh:
        hit = _admin_cache.get(key)
        if hit and now - hit[0] < _ADMIN_TTL:
            return hit[1]
    try:
        perm = await client.get_permissions(chat_id, target)
        result = bool(getattr(perm, "is_admin", False) or getattr(perm, "is_creator", False))
    except Exception:  # noqa: BLE001
        result = False
    _admin_cache[key] = (now, result)
    return result
