from __future__ import annotations

from typing import Any


async def my_id(client: Any) -> int:
    """Return the logged-in account id (cached; get_me() is a network call)."""
    cached = getattr(client, "_hapoyi_me_id", None)
    if cached:
        return int(cached)
    me = await client.get_me()
    client._hapoyi_me_id = int(me.id)
    return int(me.id)


async def my_name(client: Any) -> str:
    cached = getattr(client, "_hapoyi_me_name", None)
    if cached:
        return cached
    me = await client.get_me()
    name = " ".join(x for x in [getattr(me, "first_name", None), getattr(me, "last_name", None)] if x).strip()
    client._hapoyi_me_name = name or getattr(me, "username", None) or "من"
    client._hapoyi_me_id = int(me.id)
    return client._hapoyi_me_name
