from __future__ import annotations

import asyncio
import json
import sqlite3
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA = r"""
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS chat_settings (
    chat_id INTEGER PRIMARY KEY,
    settings_json TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS warnings (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    count INTEGER NOT NULL DEFAULT 0,
    last_reason TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS whitelist (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS autoban (
    chat_id INTEGER PRIMARY KEY,
    enabled INTEGER NOT NULL DEFAULT 0,
    action TEXT NOT NULL DEFAULT 'ban',
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS autodelete (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    enabled_at TEXT NOT NULL,
    PRIMARY KEY(chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS autoreplies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope_type TEXT NOT NULL,
    scope_id INTEGER NOT NULL DEFAULT 0,
    trigger TEXT NOT NULL,
    response TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'contains',
    enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS notes (
    owner_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    value TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, name)
);
CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    chat_id INTEGER,
    kind TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    run_at TEXT NOT NULL,
    interval_seconds INTEGER,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS price_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    operator TEXT NOT NULL,
    target REAL NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    enabled INTEGER NOT NULL DEFAULT 1,
    last_value REAL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS filters (
    chat_id INTEGER NOT NULL,
    pattern TEXT NOT NULL,
    action TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY(chat_id, pattern, action)
);
CREATE TABLE IF NOT EXISTS afk (
    owner_id INTEGER PRIMARY KEY,
    reason TEXT,
    started_at TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS afk_notified (
    owner_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    notified_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, user_id)
);
CREATE TABLE IF NOT EXISTS reactions (
    chat_id INTEGER PRIMARY KEY,
    emoji TEXT,
    enabled INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS watches (
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    needle TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY(owner_id, chat_id, kind, needle)
);
CREATE TABLE IF NOT EXISTS game_runs (
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    game TEXT NOT NULL,
    started_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, chat_id, game)
);
CREATE TABLE IF NOT EXISTS portfolio (
    owner_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    quantity REAL NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, symbol)
);
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    needle TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    UNIQUE(owner_id, chat_id, needle)
);
CREATE TABLE IF NOT EXISTS relations (
    owner_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('friend','enemy')),
    enabled INTEGER NOT NULL DEFAULT 1,
    cooldown_seconds REAL NOT NULL DEFAULT 8,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, user_id)
);
CREATE TABLE IF NOT EXISTS relation_replies (
    owner_id INTEGER NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('friend','enemy')),
    reply_text TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS game_scores (
    owner_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    game TEXT NOT NULL,
    wins INTEGER NOT NULL DEFAULT 0,
    plays INTEGER NOT NULL DEFAULT 0,
    points INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(owner_id, chat_id, game)
);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Database:
    def __init__(self, path: str | Path):
        self.path = str(path)
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        async with self._lock:
            if self._conn is not None:
                return
            self._conn = sqlite3.connect(self.path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
            self._conn.executescript(SCHEMA)
            self._conn.commit()

    async def close(self) -> None:
        async with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    def _require(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Database is not connected")
        return self._conn

    async def execute(self, sql: str, params: Iterable[Any] = ()) -> int:
        async with self._lock:
            conn = self._require()
            cur = conn.execute(sql, tuple(params))
            conn.commit()
            return cur.rowcount

    async def insert(self, sql: str, params: Iterable[Any] = ()) -> int:
        """Run an INSERT and return the new row id (0 when ignored)."""
        async with self._lock:
            conn = self._require()
            cur = conn.execute(sql, tuple(params))
            conn.commit()
            return int(cur.lastrowid or 0) if cur.rowcount > 0 else 0

    async def fetchone(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        async with self._lock:
            conn = self._require()
            return conn.execute(sql, tuple(params)).fetchone()

    async def fetchall(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        async with self._lock:
            conn = self._require()
            return conn.execute(sql, tuple(params)).fetchall()

    async def set_kv(self, key: str, value: Any) -> None:
        payload = json.dumps(value, ensure_ascii=False)
        await self.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, payload))

    async def get_kv(self, key: str, default: Any = None) -> Any:
        row = await self.fetchone("SELECT value FROM kv WHERE key=?", (key,))
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            return row["value"]

    async def update_chat_settings(self, chat_id: int, **changes: Any) -> dict[str, Any]:
        current = await self.get_kv(f"chat:{chat_id}", {})
        current.update(changes)
        await self.set_kv(f"chat:{chat_id}", current)
        return current

    async def get_chat_settings(self, chat_id: int) -> dict[str, Any]:
        return dict(await self.get_kv(f"chat:{chat_id}", {}) or {})
