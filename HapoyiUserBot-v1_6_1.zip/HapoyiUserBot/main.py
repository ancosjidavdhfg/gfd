from __future__ import annotations

import asyncio

from core.bootstrap import start


if __name__ == "__main__":
    try:
        asyncio.run(start())
    except KeyboardInterrupt:
        pass
