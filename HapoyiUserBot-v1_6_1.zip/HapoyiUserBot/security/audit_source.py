from __future__ import annotations

import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN = {
    "eval": "dynamic eval",
    "exec": "dynamic exec",
    "__import__": "dynamic import",
}
URL_RE = re.compile(r"https?://[^\"'\s)]+")


def main() -> int:
    findings = []
    urls = set()
    for path in ROOT.rglob("*.py"):
        if any(part in {"venv", ".git", "__pycache__", ".pytest_cache", "tests"} for part in path.parts):
            continue
        text = path.read_text(encoding="utf-8")
        for m in URL_RE.finditer(text):
            urls.add(m.group(0))
        try:
            tree = ast.parse(text)
        except SyntaxError:
            findings.append((path, 1, "syntax error"))
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and node.id in {"eval", "exec"}:
                findings.append((path, node.lineno, FORBIDDEN[node.id]))
    print("== Hāpoyi source audit ==")
    print("Outbound URLs:")
    for url in sorted(urls):
        print("  ", url)
    if findings:
        print("\nFindings:")
        for path, line, why in findings:
            print(f"  {path}:{line}: {why}")
        return 2
    print("\nNo eval/exec calls found in source.")
    print("Tests are excluded because they may use controlled AST fixtures; this audit targets production source.")
    print("Important: this audit is source-level only; dependencies must be trusted/audited separately.")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
