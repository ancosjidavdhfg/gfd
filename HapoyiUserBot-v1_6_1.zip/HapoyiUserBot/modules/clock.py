from __future__ import annotations
import os
from datetime import datetime
from zoneinfo import ZoneInfo
from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."

def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}clock$"))
    async def clock(event):
        zone=os.getenv("TIMEZONE","Asia/Tehran")
        await event.edit(f"🕐 {datetime.now(ZoneInfo(zone)).strftime('%H:%M:%S')} — {zone}")
