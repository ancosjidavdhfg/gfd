from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from telethon import events
from telethon.errors import RPCError
from telethon.events import ChatAction

from core.identity import my_id
from core.actions import UnsupportedChat, edit_banned
from core.permissions import require_group_right, resolve_target, target_is_admin
from utils.rights import ban_rights, mute_rights

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}autoban\s+(on|off)(?:\s+(ban|mute|delete))?$"))
    async def autoban_cmd(event):
        if not event.is_group:
            return
        p = await require_group_right(client, event.chat_id, "ban_users")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        mode = event.pattern_match.group(2) or "ban"
        enabled = event.pattern_match.group(1) == "on"
        await db.execute("INSERT INTO autoban(chat_id,enabled,action,updated_at) VALUES(?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET enabled=excluded.enabled,action=excluded.action,updated_at=excluded.updated_at", (event.chat_id, int(enabled), mode, datetime.now(timezone.utc).isoformat()))
        await event.reply(f"🛡️ AutoBan {'روشن' if enabled else 'خاموش'} — action={mode}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}whitelist\s+(add|del|list)(?:\s+(\S+))?$"))
    async def whitelist(event):
        if not event.is_group:
            return
        p = await require_group_right(client, event.chat_id, "ban_users")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        action, arg = event.pattern_match.group(1), event.pattern_match.group(2)
        if action == "list":
            rows = await db.fetchall("SELECT user_id FROM whitelist WHERE chat_id=? ORDER BY user_id", (event.chat_id,))
            return await event.reply("✅ Whitelist:\n" + "\n".join(f"• {r['user_id']}" for r in rows) if rows else "✅ Whitelist خالی است.")
        target = await resolve_target(event, arg)
        if target is None:
            return await event.reply("ریپلای یا username/ID بده.")
        uid = int(getattr(target, "id", target))
        if action == "add":
            await db.execute("INSERT OR IGNORE INTO whitelist(chat_id,user_id) VALUES(?,?)", (event.chat_id, uid))
            return await event.reply("✅ به whitelist اضافه شد.")
        await db.execute("DELETE FROM whitelist WHERE chat_id=? AND user_id=?", (event.chat_id, uid))
        await event.reply("✅ از whitelist حذف شد.")

    @client.on(ChatAction)
    async def chat_action(event):
        if not event.is_group or not (event.user_joined or event.user_added):
            return
        cfg = await db.fetchone("SELECT enabled,action FROM autoban WHERE chat_id=?", (event.chat_id,))
        if not cfg or not cfg["enabled"] or cfg["action"] == "delete":
            return
        perm = await require_group_right(client, event.chat_id, "ban_users", fresh=False)
        if not perm.allowed:
            return
        try:
            users = await event.get_users()
        except Exception:  # noqa: BLE001
            users = []
        me_id = await my_id(client)
        for user in users or []:
            uid = int(user.id)
            if uid == me_id:
                continue
            white = await db.fetchone("SELECT 1 FROM whitelist WHERE chat_id=? AND user_id=?", (event.chat_id, uid))
            if white or await target_is_admin(client, event.chat_id, user, fresh=False):
                continue
            try:
                await edit_banned(client, event, user, mute_rights() if cfg["action"] == "mute" else ban_rights())
            except (RPCError, UnsupportedChat):
                pass

    @client.on(events.NewMessage)
    async def autodelete_handler(event):
        if event.out or event.sender_id is None:
            return
        row = await db.fetchone("SELECT enabled, enabled_at FROM autodelete WHERE chat_id=? AND user_id=?", (event.chat_id, int(event.sender_id)))
        if not row or not row["enabled"]:
            return
        if event.date.isoformat() < row["enabled_at"]:
            return
        if event.is_group:
            perm = await require_group_right(client, event.chat_id, "delete_messages", fresh=False)
            if not perm.allowed:
                await db.execute("UPDATE autodelete SET enabled=0 WHERE chat_id=? AND user_id=?", (event.chat_id, int(event.sender_id)))
                return
        try:
            await event.delete()
        except RPCError:
            pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}autodelete\s+(enable|disable|list)(?:\s+(\S+))?$"))
    async def autodelete_cmd(event):
        action, arg = event.pattern_match.group(1), event.pattern_match.group(2)
        if event.is_group:
            p = await require_group_right(client, event.chat_id, "delete_messages")
            if not p.allowed:
                return await event.reply("❌ " + p.reason)
        if action == "list":
            rows = await db.fetchall("SELECT user_id,enabled,enabled_at FROM autodelete WHERE chat_id=? ORDER BY user_id", (event.chat_id,))
            return await event.reply("🧹 AutoDelete:\n" + "\n".join(f"• {r['user_id']} {'ON' if r['enabled'] else 'OFF'} from {r['enabled_at']}" for r in rows) if rows else "🧹 لیست خالی است.")
        target = await resolve_target(event, arg)
        if target is None:
            return await event.reply("ریپلای یا @username یا ID بده.")
        uid = int(getattr(target, "id", target))
        if action == "enable":
            await db.execute("INSERT INTO autodelete(chat_id,user_id,enabled,enabled_at) VALUES(?,?,1,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET enabled=1,enabled_at=excluded.enabled_at", (event.chat_id, uid, datetime.now(timezone.utc).isoformat()))
            return await event.reply("🧹 AutoDelete فعال شد؛ فقط پیام‌های بعد از همین لحظه حذف می‌شوند.")
        await db.execute("UPDATE autodelete SET enabled=0 WHERE chat_id=? AND user_id=?", (event.chat_id, uid))
        await event.reply("✅ AutoDelete غیرفعال شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}filter\s+(add|del|list)(?:\s+(.+))?$"))
    async def filter_cmd(event):
        if not event.is_group:
            return
        action, text = event.pattern_match.group(1), event.pattern_match.group(2)
        p = await require_group_right(client, event.chat_id, "delete_messages")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        if action == "list":
            rows = await db.fetchall("SELECT pattern,action FROM filters WHERE chat_id=? AND enabled=1", (event.chat_id,))
            return await event.reply("🚫 Filters:\n" + "\n".join(f"• {r['pattern']} → {r['action']}" for r in rows) if rows else "🚫 فیلتر نداریم.")
        if not text:
            return await event.reply("متن فیلتر را بده.")
        if action == "add":
            await db.execute("INSERT OR IGNORE INTO filters(chat_id,pattern,action,enabled) VALUES(?,?,?,1)", (event.chat_id, text.strip().lower(), "delete"))
            return await event.reply("✅ Filter added")
        await db.execute("DELETE FROM filters WHERE chat_id=? AND pattern=?", (event.chat_id, text.strip().lower()))
        await event.reply("✅ Filter removed")

    @client.on(events.NewMessage)
    async def filter_handler(event):
        if not event.is_group or event.out or not event.raw_text or event.raw_text.startswith(PREFIX):
            return
        patterns = await db.fetchall("SELECT pattern,action FROM filters WHERE chat_id=? AND enabled=1", (event.chat_id,))
        if not patterns:
            return
        if event.sender_id and (
            await db.fetchone("SELECT 1 FROM whitelist WHERE chat_id=? AND user_id=?", (event.chat_id, int(event.sender_id)))
            or await target_is_admin(client, event.chat_id, int(event.sender_id), fresh=False)
        ):
            return
        low = event.raw_text.lower()
        for row in patterns:
            if row["pattern"] in low:
                try:
                    await event.delete()
                except RPCError:
                    pass
                break
