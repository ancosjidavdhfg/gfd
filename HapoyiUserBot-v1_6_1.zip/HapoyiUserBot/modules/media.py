from __future__ import annotations

import os
from pathlib import Path
from telethon import events
from PIL import Image, ImageEnhance, ImageOps

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
MEDIA_DIR = Path(__file__).resolve().parents[1] / "data" / "media"
MEDIA_DIR.mkdir(parents=True, exist_ok=True)


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}download$"))
    async def download(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی مدیا.")
        m = await event.get_reply_message()
        if not m.media:
            return await event.reply("❌ این پیام مدیا ندارد.")
        path = await m.download_media(file=str(MEDIA_DIR))
        await event.reply(f"✅ دانلود شد:\n{Path(path).name}" if path else "❌ دانلود نشد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}rename\s+(.+)$"))
    async def rename(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی فایل.")
        m = await event.get_reply_message()
        path = await m.download_media(file=str(MEDIA_DIR))
        if not path:
            return await event.reply("❌ دانلود نشد.")
        new = MEDIA_DIR / event.pattern_match.group(1).strip()
        Path(path).replace(new)
        await client.send_file(event.chat_id, str(new))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}sticker$"))
    async def sticker(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی عکس/GIF.")
        m = await event.get_reply_message()
        path = await m.download_media(file=str(MEDIA_DIR))
        if not path:
            return await event.reply("❌ دانلود نشد.")
        try:
            im = Image.open(path).convert("RGBA")
            im.thumbnail((512, 512), Image.Resampling.LANCZOS)
            out = str(Path(path).with_suffix(".webp"))
            im.save(out, "WEBP", lossless=True, quality=90)
            await client.send_file(event.chat_id, out, force_document=False)
            await event.delete()
        except Exception as exc:
            await event.reply(f"❌ تبدیل نشد: {exc}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}resize\s+(\d+)\s+(\d+)$"))
    async def resize(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی عکس.")
        m = await event.get_reply_message(); path = await m.download_media(file=str(MEDIA_DIR))
        if not path:
            return await event.reply("❌ دانلود نشد.")
        w, h = int(event.pattern_match.group(1)), int(event.pattern_match.group(2))
        if w * h > 20_000_000:
            return await event.reply("❌ اندازه خیلی بزرگ است.")
        im = Image.open(path).convert("RGB").resize((w,h), Image.Resampling.LANCZOS)
        out = str(Path(path).with_name(Path(path).stem + "_resize.jpg")); im.save(out, quality=90)
        await client.send_file(event.chat_id, out)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}watermark\s+(.+)$"))
    async def watermark(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی عکس.")
        m = await event.get_reply_message(); path = await m.download_media(file=str(MEDIA_DIR))
        if not path:
            return await event.reply("❌ دانلود نشد.")
        try:
            from PIL import ImageDraw, ImageFont
            im = Image.open(path).convert("RGBA")
            draw = ImageDraw.Draw(im)
            text = event.pattern_match.group(1)
            draw.text((20, im.height - 50), text, fill=(255,255,255,180), stroke_width=2, stroke_fill=(0,0,0,180))
            out = str(Path(path).with_name(Path(path).stem + "_wm.png")); im.save(out)
            await client.send_file(event.chat_id, out)
        except Exception as exc:
            await event.reply(f"❌ Watermark failed: {exc}")
