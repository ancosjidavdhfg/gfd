from __future__ import annotations

import asyncio
import operator
import os
from datetime import datetime, timezone

from core.identity import my_id
from telethon import events

from providers.crypto import MarketProvider
from utils.formatting import fmt_money

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
OPS = {">": operator.gt, "<": operator.lt, ">=": operator.ge, "<=": operator.le, "=": operator.eq}


def setup(client, db):
    provider = MarketProvider(cache_seconds=10)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}alert\s+(\S+)\s*(>=|<=|>|<|=)\s*([0-9.]+)$"))
    async def alert_add(event):
        symbol, op, target = event.pattern_match.group(1), event.pattern_match.group(2), float(event.pattern_match.group(3))
        alert_id = await db.insert("INSERT INTO price_alerts(owner_id,chat_id,symbol,operator,target,created_at) VALUES(?,?,?,?,?,?)", ((await my_id(client)), event.chat_id, symbol, op, target, datetime.now(timezone.utc).isoformat()))
        await event.reply(f"🔔 Alert #{alert_id} ثبت شد: {symbol} {op} {target}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}alerts$"))
    async def alerts(event):
        rows = await db.fetchall("SELECT id,symbol,operator,target,enabled,last_value FROM price_alerts WHERE owner_id=? ORDER BY id DESC", ((await my_id(client)),))
        if not rows:
            return await event.reply("🔔 Alert نداری.")
        await event.reply("🔔 Alerts\n" + "\n".join(f"#{r['id']} {r['symbol']} {r['operator']} {r['target']} {'ON' if r['enabled'] else 'OFF'}" for r in rows))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}alertdel\s+(\d+)$"))
    async def alert_del(event):
        await db.execute("DELETE FROM price_alerts WHERE id=? AND owner_id=?", (int(event.pattern_match.group(1)), (await my_id(client))))
        await event.reply("✅ Alert حذف شد.")

    async def loop():
        while True:
            try:
                rows = await db.fetchall("SELECT id,owner_id,chat_id,symbol,operator,target FROM price_alerts WHERE enabled=1")
                for row in rows:
                    try:
                        q = await provider.quote(row["symbol"])
                        if OPS[row["operator"]](q.usd, row["target"]):
                            await client.send_message(row["chat_id"], f"🚨 Price Alert\n{q.symbol} = ${fmt_money(q.usd, 4)}\n🎯 شرط: {row['operator']} {row['target']}\n🕐 {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
                            await db.execute("UPDATE price_alerts SET enabled=0,last_value=? WHERE id=?", (q.usd, row["id"]))
                    except Exception:
                        continue
            except Exception:
                pass
            await asyncio.sleep(30)

    asyncio.create_task(loop())
