from __future__ import annotations

import os
import re
from core.identity import my_id
from telethon import events
from telethon.errors import RPCError

from utils.react import send_reaction

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}autoreply\s+(add|del|list|on|off)(?:\s+(.+?))?(?:\s+=>\s+(.+))?$"))
    async def autoreply_cmd(event):
        action, trigger, response = event.pattern_match.group(1), event.pattern_match.group(2), event.pattern_match.group(3)
        scope = event.chat_id if event.is_group else 0
        if action == "list":
            rows = await db.fetchall("SELECT id,trigger,response,mode,enabled FROM autoreplies WHERE scope_id=? ORDER BY id", (scope,))
            return await event.reply("🤖 AutoReply:\n" + "\n".join(f"#{r['id']} {r['trigger']} → {r['response']} {'ON' if r['enabled'] else 'OFF'}" for r in rows) if rows else "🤖 خالی است.")
        if action in {"on", "off"}:
            await db.execute("UPDATE autoreplies SET enabled=? WHERE scope_id=?", (int(action == "on"), scope))
            return await event.reply("✅ AutoReply " + ("روشن" if action == "on" else "خاموش"))
        if not trigger:
            return await event.reply("مثال: .autoreply add سلام => سلام داداش ❤️")
        if action == "add":
            if not response:
                return await event.reply("فرمت: .autoreply add trigger => response")
            await db.execute("INSERT INTO autoreplies(scope_type,scope_id,trigger,response,mode,enabled) VALUES('chat',?,?,?,?,1)", (scope, trigger.strip().lower(), response, "contains"))
            return await event.reply("✅ AutoReply اضافه شد.")
        try:
            rid = int(trigger.lstrip("#"))
        except ValueError:
            return await event.reply("برای حذف ID بده؛ مثل .autoreply del 3")
        await db.execute("DELETE FROM autoreplies WHERE id=? AND scope_id=?", (rid, scope))
        await event.reply("✅ حذف شد.")

    @client.on(events.NewMessage)
    async def autoreply_handler(event):
        # Never answer ourselves (that was a self-reply loop) or Telegram's service account.
        if event.out or not event.raw_text or event.raw_text.startswith(PREFIX) or event.sender_id == 777000:
            return
        scope = event.chat_id if event.is_group else 0
        rows = await db.fetchall("SELECT trigger,response,mode,enabled FROM autoreplies WHERE scope_id=? AND enabled=1", (scope,))
        low = event.raw_text.lower()
        for row in rows:
            try:
                matched = re.search(row["trigger"], event.raw_text, re.I) if row["mode"] == "regex" else row["trigger"] in low
            except re.error:
                matched = False
            if matched:
                await event.reply(row["response"])
                break

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}autoreact\s+(?!off$)(\S+)$"))
    async def autoreact_cmd(event):
        emoji = event.pattern_match.group(1)
        await db.execute("INSERT INTO reactions(chat_id,emoji,enabled) VALUES(?,?,1) ON CONFLICT(chat_id) DO UPDATE SET emoji=excluded.emoji,enabled=1", (event.chat_id, emoji))
        await event.reply(f"❤️ AutoReact = {emoji}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}autoreact\s+off$"))
    async def autoreact_off(event):
        await db.execute("UPDATE reactions SET enabled=0 WHERE chat_id=?", (event.chat_id,))
        await event.reply("✅ AutoReact خاموش شد.")

    @client.on(events.NewMessage)
    async def autoreact_handler(event):
        if event.out or not event.raw_text:
            return
        row = await db.fetchone("SELECT emoji,enabled FROM reactions WHERE chat_id=? AND enabled=1", (event.chat_id,))
        if not row:
            return
        try:
            await send_reaction(client, event.chat_id, event.id, row["emoji"])
        except Exception:  # noqa: BLE001
            return

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}watch\s+(add|del|list)(?:\s+(\S+))?(?:\s+(.+))?$"))
    async def watch_cmd(event):
        action, chat, needle = event.pattern_match.group(1), event.pattern_match.group(2), event.pattern_match.group(3)
        owner = (await my_id(client))
        if action == "list":
            rows = await db.fetchall("SELECT chat_id,kind,needle FROM watches WHERE owner_id=? AND enabled=1", (owner,))
            return await event.reply("👀 Watches:\n" + "\n".join(f"• {r['chat_id']} {r['kind']} {r['needle'] or ''}" for r in rows) if rows else "👀 خالی است.")
        if not chat:
            return await event.reply(".watch add @channel [keyword]")
        try:
            chat_id = int(chat) if chat.lstrip("-").isdigit() else (await client.get_entity(chat)).id
        except Exception:
            return await event.reply("❌ chat پیدا نشد.")
        kind = "keyword" if needle else "new_message"
        if action == "add":
            await db.execute("INSERT OR IGNORE INTO watches(owner_id,chat_id,kind,needle,enabled) VALUES(?,?,?,?,1)", (owner,chat_id,kind,needle))
            return await event.reply("✅ Watch اضافه شد.")
        await db.execute("DELETE FROM watches WHERE owner_id=? AND chat_id=?", (owner,chat_id))
        await event.reply("✅ Watch حذف شد.")

    @client.on(events.NewMessage)
    async def watch_handler(event):
        if event.out or not event.raw_text:
            return
        rows = await db.fetchall("SELECT owner_id,needle FROM watches WHERE chat_id=? AND enabled=1", (event.chat_id,))
        if not rows:
            return
        for row in rows:
            needle = row["needle"]
            if not needle or needle.lower() in event.raw_text.lower():
                await client.send_message(row["owner_id"], f"👀 Watch\nChat: {event.chat_id}\nMessage: {event.raw_text[:3000]}")
