from __future__ import annotations

import asyncio
import os
import re

from telethon import events
from telethon.errors import RPCError

from core.permissions import require_group_right
from utils.formatting import parse_duration

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    async def delete_later(chat_id: int, ids: list[int], seconds: int):
        await asyncio.sleep(seconds)
        try:
            await client.delete_messages(chat_id, ids)
        except RPCError:
            pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}delafter\s+(\S+)$"))
    async def delafter(event):
        try:
            seconds = parse_duration(event.pattern_match.group(1))
        except ValueError as exc:
            return await event.reply("❌ " + str(exc))
        if not event.is_reply:
            return await event.reply("❌ روی پیام Reply کن.")
        if event.is_group:
            p = await require_group_right(client, event.chat_id, "delete_messages")
            if not p.allowed:
                return await event.reply("❌ " + p.reason)
        reply = await event.get_reply_message()
        task = asyncio.create_task(delete_later(event.chat_id, [reply.id, event.id], seconds))
        await event.reply(f"🧹 حذف زمان‌بندی شد: {event.pattern_match.group(1)}")
        task.add_done_callback(lambda t: t.exception() if not t.cancelled() else None)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}selfdestruct\s+(\S+)\s+(.+)$"))
    async def selfdestruct(event):
        try:
            seconds = parse_duration(event.pattern_match.group(1))
        except ValueError as exc:
            return await event.reply("❌ " + str(exc))
        msg = await event.reply(event.pattern_match.group(2))
        asyncio.create_task(delete_later(event.chat_id, [msg.id], seconds))
        await event.delete()

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}cleanme(?:\s+(\d+))?$"))
    async def cleanme(event):
        n = max(1, min(int(event.pattern_match.group(1) or 20), 200))
        ids = []
        async for msg in client.iter_messages(event.chat_id, from_user="me", limit=n + 1):
            ids.append(msg.id)
        if event.id not in ids:
            ids.append(event.id)
        await client.delete_messages(event.chat_id, ids)
