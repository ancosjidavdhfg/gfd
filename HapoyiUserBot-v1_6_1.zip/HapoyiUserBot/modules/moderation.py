from __future__ import annotations

import asyncio
import os
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

from telethon import events
from telethon.errors import RPCError

from core.actions import UnsupportedChat, edit_banned
from core.permissions import ensure_target_not_self, get_real_reply, require_group_right, resolve_target, target_is_admin
from utils.rights import mute_rights
from utils.formatting import parse_duration

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    flood: dict[int, dict[int, deque[float]]] = defaultdict(lambda: defaultdict(lambda: deque(maxlen=100)))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}warn(?:\s+(\S+))?(?:\s+(.+))?$"))
    async def warn(event):
        if not event.is_group:
            return
        p = await require_group_right(client, event.chat_id, "delete_messages")
        if not p.allowed:
            return await event.reply("❌ " + p.reason)
        explicit, reason = event.pattern_match.group(1), event.pattern_match.group(2)
        if explicit and await get_real_reply(event) is not None and not (explicit.startswith("@") or explicit.lstrip("-").isdigit()):
            # replying + free text: everything after the command is the reason
            explicit, reason = None, f"{explicit} {reason}".strip() if reason else explicit
        target = await resolve_target(event, explicit)
        if target is None:
            return await event.reply("❌ Reply کن یا username/ID معتبر بده (کاربر پیدا نشد).")
        safe = await ensure_target_not_self(client, target)
        if not safe.allowed:
            return await event.reply("❌ " + safe.reason)
        uid = int(getattr(target, "id", target)); reason = reason or "بدون دلیل"
        row = await db.fetchone("SELECT count FROM warnings WHERE chat_id=? AND user_id=?", (event.chat_id, uid))
        count = int(row["count"] if row else 0) + 1
        await db.execute("INSERT INTO warnings(chat_id,user_id,count,last_reason,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET count=excluded.count,last_reason=excluded.last_reason,updated_at=excluded.updated_at", (event.chat_id, uid, count, reason, datetime.now(timezone.utc).isoformat()))
        await event.reply(f"⚠️ Warning {count}/3\nID: {uid}\nدلیل: {reason}")
        if count >= 3 and not await target_is_admin(client, event.chat_id, target):
            try:
                await edit_banned(client, event, target, mute_rights())
                await event.reply("🔇 به دلیل ۳ اخطار mute شد.")
            except (RPCError, UnsupportedChat) as exc:
                await event.reply(f"❌ میوت خودکار انجام نشد: {exc.__class__.__name__}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}warnings(?:\s+(\S+))?$"))
    async def warnings(event):
        target = await resolve_target(event, event.pattern_match.group(1))
        if target is None:
            target = await event.get_sender()
        row = await db.fetchone("SELECT count,last_reason,updated_at FROM warnings WHERE chat_id=? AND user_id=?", (event.chat_id, int(getattr(target,'id',target))))
        await event.reply(f"⚠️ warnings: {row['count'] if row else 0}\nreason: {row['last_reason'] if row else '—'}\nupdated: {row['updated_at'] if row else '—'}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}unwarn(?:\s+(\S+))?$"))
    async def unwarn(event):
        target = await resolve_target(event, event.pattern_match.group(1))
        if target is None:
            return await event.reply("❌ Reply یا target")
        uid = int(getattr(target,'id',target))
        row = await db.fetchone("SELECT count FROM warnings WHERE chat_id=? AND user_id=?", (event.chat_id,uid))
        new = max(0, int(row['count'])-1) if row else 0
        await db.execute("UPDATE warnings SET count=? WHERE chat_id=? AND user_id=?", (new,event.chat_id,uid))
        await event.reply(f"✅ warnings = {new}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}flood\s+(on|off)(?:\s+(\d+)\s+(\d+))?$"))
    async def flood_cmd(event):
        if not event.is_group:
            return
        action = event.pattern_match.group(1)
        count = int(event.pattern_match.group(2) or 8); seconds = int(event.pattern_match.group(3) or 10)
        await db.update_chat_settings(event.chat_id, flood_enabled=action == 'on', flood_count=count, flood_seconds=seconds)
        await event.reply(f"🌊 Flood {'ON' if action == 'on' else 'OFF'} — {count}/{seconds}s")

    @client.on(events.NewMessage)
    async def flood_handler(event):
        if not event.is_group or event.out or not event.sender_id:
            return
        cfg = await db.get_chat_settings(event.chat_id)
        if not cfg.get("flood_enabled"):
            return
        now = time.monotonic(); q = flood[event.chat_id][int(event.sender_id)]
        q.append(now)
        threshold = int(cfg.get("flood_count",8)); window = int(cfg.get("flood_seconds",10))
        while q and now-q[0] > window:
            q.popleft()
        if len(q) >= threshold:
            if await target_is_admin(client, event.chat_id, int(event.sender_id), fresh=False):
                q.clear()
                return
            p = await require_group_right(client, event.chat_id, "delete_messages", fresh=False)
            if p.allowed:
                try:
                    await event.delete()
                except RPCError:
                    pass
                q.clear()
