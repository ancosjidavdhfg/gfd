from __future__ import annotations

import os
import re
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events

from core.permissions import get_real_reply
from utils.react import send_reaction

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}id(?:\s+(\S+))?$"))
    async def ident(event):
        arg = event.pattern_match.group(1)
        target = await event.get_sender() if not arg else (int(arg) if arg.lstrip("-").isdigit() else await client.get_entity(arg))
        if not arg and event.is_group:
            chat = await event.get_chat()
            return await event.reply(f"🆔 Chat ID: `{event.chat_id}`\nType: {chat.__class__.__name__}")
        await event.reply(f"🆔 ID: `{getattr(target,'id',target)}`\nUsername: `@{getattr(target,'username',None) or '—'}`")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}msginfo$"))
    async def msginfo(event):
        if not event.is_reply:
            return await event.reply("❌ Reply کن.")
        m = await event.get_reply_message()
        await event.reply(f"📨 Message\nID: {m.id}\nSender: {m.sender_id}\nDate: {m.date}\nReply: {m.reply_to_msg_id}\nMedia: {type(m.media).__name__ if m.media else 'none'}\nViews: {m.views or 0}\nForwards: {m.forwards or 0}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}save$"))
    async def save(event):
        if not event.is_reply:
            return await event.reply("❌ Reply کن.")
        m = await event.get_reply_message()
        await client.forward_messages("me", m)
        await event.reply("✅ به Saved Messages فوروارد شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}search\s+(.+)$"))
    async def search(event):
        needle = event.pattern_match.group(1)
        rows = []
        async for m in client.iter_messages(event.chat_id, search=needle, limit=20):
            rows.append(f"• {m.id} | {m.date.strftime('%Y-%m-%d %H:%M')} | {m.raw_text[:120]}")
        await event.reply("🔎 Search\n" + "\n".join(rows) if rows else "🔎 چیزی پیدا نشد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}readall$"))
    async def readall(event):
        await client.send_read_acknowledge(event.chat_id, clear_mentions=True, clear_reactions=True)
        await event.reply("✅ خوانده شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}react\s+(\S+)$"))
    async def react(event):
        m = await get_real_reply(event)
        if m is None:
            return await event.reply("❌ Reply کن.")
        await send_reaction(client, event.chat_id, m.id, event.pattern_match.group(1))
        await event.delete()
