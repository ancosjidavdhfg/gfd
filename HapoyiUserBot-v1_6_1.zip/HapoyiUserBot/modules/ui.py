from __future__ import annotations

import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from telethon import Button, TelegramClient, events

from core.identity import my_id
from providers.crypto import MarketProvider
from providers.fx import FXProvider

log = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
UI_ENABLED = os.getenv("UI_ENABLED", "true").lower() not in {"0", "false", "no"}
OWNER_ID = int(os.getenv("HAPOYI_OWNER_ID", "0") or 0)
BOT_SESSION = os.getenv(
    "HAPOYI_BOT_SESSION",
    str(Path(__file__).resolve().parents[1] / "data" / "hapoyi_ui_bot"),
)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
TIMEZONE = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"

_bot: TelegramClient | None = None
_user_client: Any = None

SECTIONS: dict[str, tuple[str, str, tuple[str, ...]]] = {
    "relations": (
        "🤝 دوست / دشمن",
        "پاسخ‌های تصادفی برای کاربران مشخص با کنترل cooldown",
        ("friend add", "friend list", "friend reply", "enemy add", "enemy list", "enemy reply", "relation stats", "relation replies"),
    ),
    "admin": (
        "🛡 مدیریت گروه",
        "ابزارهای مدیریت و کنترل اعضای گروه",
        ("ban", "unban", "kick", "mute", "unmute", "warn", "warnings", "unwarn", "del", "purge", "pin", "unpin", "admins"),
    ),
    "security": (
        "🔐 امنیت و نگهبان",
        "محافظت، فیلتر، AutoDelete و AutoBan",
        ("autoban", "whitelist", "autodelete", "filter", "flood", "safety", "floodguard"),
    ),
    "chat": (
        "👥 امکانات چت",
        "خوش‌آمد، خروج، لینک‌گارد و کنترل نرخ پیام",
        ("welcome", "leave", "linkguard", "linkguard threshold", "rate"),
    ),
    "personal": (
        "🧠 شخصی",
        "AFK، یادداشت، یادآوری، پروفایل و اطلاعات",
        ("afk", "back", "note", "remind", "clock", "profileclock", "bio", "stats", "userinfo", "chatinfo", "time"),
    ),
    "crypto": (
        "💰 بازار و کریپتو",
        "قیمت‌ها، هشدارها و پرتفوی",
        ("price", "market", "alert", "alerts", "alertdel", "hold", "portfolio"),
    ),
    "tools": (
        "🧰 ابزارها",
        "محاسبه، پیام، جست‌وجو و واکنش",
        ("calc", "msginfo", "id", "save", "search", "readall", "react", "rawchat"),
    ),
    "media": (
        "🎞️ مدیا",
        "دانلود، استیکر، تغییر اندازه و واترمارک",
        ("download", "sticker", "rename", "resize", "watermark"),
    ),
    "message": (
        "🧹 ابزار پیام",
        "حذف زمان‌دار، Self-destruct و پاک‌سازی",
        ("delafter", "selfdestruct", "cleanme"),
    ),
    "games": (
        "🎲 بازی‌ها",
        "Casino و بازی‌های تاسی",
        ("casino", "slots", "dice", "dart", "bowling", "basket", "football", "game list", "game cancel", "coin", "rps", "roulette", "8ball", "blackjack", "roll", "choose", "game score", "leaderboard"),
    ),
    "automation": (
        "⏰ اتوماسیون",
        "AutoReply، AutoReact، Watch و Notify",
        ("autoreply", "watch", "autoreact", "notify", "jobs", "jobdel"),
    ),
    "audit": (
        "🔎 Audit خصوصی",
        "لاگ پیام، ویرایش و حذف برای چت‌های انتخابی",
        ("audit on", "audit off", "audit list", "audit status", "audit purge", "audit test"),
    ),
    "channels": (
        "📢 کانال‌ها",
        "کامنت و ابزارهای مرتبط با کانال",
        ("comment", "comments"),
    ),
}


def _now() -> str:
    try:
        zone = ZoneInfo(TIMEZONE)
    except Exception:
        zone = ZoneInfo("UTC")
    return datetime.now(zone).strftime("%Y-%m-%d %H:%M:%S")


def _home_buttons():
    return [
        [Button.inline("🛡 مدیریت", b"ui:sec:admin"), Button.inline("🔐 امنیت", b"ui:sec:security")],
        [Button.inline("🤝 دوست/دشمن", b"ui:sec:relations"), Button.inline("👥 چت", b"ui:sec:chat")],
        [Button.inline("🧠 شخصی", b"ui:sec:personal"), Button.inline("💰 بازار", b"ui:market")],
        [Button.inline("🧰 ابزار", b"ui:sec:tools"), Button.inline("🎞️ مدیا", b"ui:sec:media")],
        [Button.inline("🧹 پیام", b"ui:sec:message"), Button.inline("🎲 بازی", b"ui:sec:games")],
        [Button.inline("⏰ اتوماسیون", b"ui:sec:automation"), Button.inline("📢 کانال", b"ui:sec:channels")],
        [Button.inline("🔎 Audit خصوصی", b"ui:sec:audit"), Button.inline("ℹ️ درباره", b"ui:about")],
        [Button.inline("⚙️ سیستم", b"ui:system"), Button.inline("💵 قیمت سریع", b"ui:quick")],
        [Button.inline("📄 Help.txt", b"ui:helpfile")],
    ]


def _nav_buttons(back: str = "ui:home"):
    return [[Button.inline("⬅️ برگشت", back.encode()), Button.inline("🏠 خانه", b"ui:home")]]


def _home_text() -> str:
    return (
        "<b>🧩 Hāpoyi UserBot</b>\n\n"
        "مرکز کنترل سلف آماده‌ست. 😎\n"
        "از دکمه‌ها وارد هر بخش شو؛ لازم نیست اسم تک‌تک دستورها یادت بمونه.\n\n"
        "<b>حالت اجرا:</b> UserBot + Assistant UI\n"
        f"<b>Prefix:</b> <code>{PREFIX}</code>\n"
        f"<b>زمان:</b> <code>{_now()}</code>"
    )


def _section_text(key: str) -> str:
    title, description, commands = SECTIONS[key]
    lines = [f"<b>{title}</b>", "", description, "", "<b>دستورها:</b>"]
    for command in commands:
        lines.append(f"• <code>{PREFIX}{command}</code>")
    lines.extend(["", "برای اجرای دستور، آن را در همان چت بفرست."])
    return "\n".join(lines)


def _section_buttons(key: str):
    # Put useful navigation first. Command names are intentionally shown as text,
    # because a user-account cannot generate Telegram inline callback markup itself.
    return _nav_buttons()


def _quick_buttons():
    return [
        [Button.inline("💵 دلار", b"ui:q:USD"), Button.inline("₿ BTC", b"ui:q:BTC")],
        [Button.inline("♦️ ETH", b"ui:q:ETH"), Button.inline("◎ SOL", b"ui:q:SOL")],
        [Button.inline("💎 USDT", b"ui:q:USDT"), Button.inline("💠 TON", b"ui:q:TON")],
        [Button.inline("⬅️ برگشت", b"ui:home")],
    ]


def _about_text() -> str:
    return (
        "<b>🧩 Hāpoyi UserBot</b>\n\n"
        "یک UserBot ماژولار بر پایهٔ Telethon.\n"
        "این پیام و دکمه‌ها از Assistant Bot می‌آیند و عملیات واقعی روی UserBot اجرا می‌شود.\n\n"
        "🔒 Callbackها فقط برای Owner پذیرفته می‌شوند.\n"
        f"🕐 {_now()}"
    )


def _system_text() -> str:
    summary = "وضعیت ماژول‌ها در دسترس نیست"
    if _user_client is not None:
        registry = getattr(_user_client, "_hapoyi_registry", None)
        if registry is not None:
            try:
                summary = registry.summary()
            except Exception:
                pass
    return (
        "<b>⚙️ وضعیت سیستم</b>\n\n"
        "🟢 Assistant UI: فعال\n"
        f"🧩 {summary}\n"
        "🗄️ SQLite: فعال\n"
        "📡 Telethon: 1.45.x\n"
        f"🕐 {_now()}"
    )


async def _render_market() -> str:
    provider = MarketProvider()
    fx = FXProvider(cache_seconds=60)
    symbols = ["BTC", "ETH", "SOL", "USDT", "TON"]
    rows = ["<b>💰 Market Dashboard</b>", ""]
    for symbol in symbols:
        try:
            if symbol == "USDT":
                q = await provider.quote(symbol)
            else:
                q = await provider.quote(symbol)
            toman = f"{q.toman:,.0f} تومان" if q.toman is not None else "—"
            change = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
            rows.append(f"<b>{q.symbol}</b>  ${q.usd:,.6f}  |  {toman}  |  {change}")
        except Exception as exc:
            rows.append(f"<b>{symbol}</b>  ❌ {exc.__class__.__name__}")
    try:
        usd = await fx.usd_to_irr()
        rows.append("")
        rows.append(f"💵 USD: {usd / 10:,.0f} تومان")
    except Exception:
        pass
    rows.extend(["", f"🕐 {_now()}"])
    return "\n".join(rows)


async def _send_menu(event) -> None:
    if _bot is None:
        await event.reply(
            "❌ منوی دکمه‌ای فعال نیست.\n"
            "در .env مقدار BOT_TOKEN مربوط به Assistant Bot را تنظیم کن و سلف را ری‌استارت کن."
        )
        return
    try:
        await _bot.send_message(event.chat_id, _home_text(), parse_mode="html", buttons=_home_buttons())
        if getattr(event, "out", False):
            try:
                await event.delete()
            except Exception:
                pass
    except Exception as exc:
        await event.reply(
            "❌ Assistant Bot نتوانست منو را اینجا بفرستد.\n"
            f"{exc.__class__.__name__}: {exc}\n\n"
            "در گروه‌ها مطمئن شو Assistant Bot عضو گروه است و اجازهٔ ارسال پیام دارد."
        )


async def setup(client, db):
    global _bot, _user_client, OWNER_ID
    _user_client = client
    if OWNER_ID <= 0:
        OWNER_ID = int(os.getenv("HAPOYI_OWNER_ID", "0") or 0)

    from telethon import events as user_events

    @client.on(user_events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}menu$"))
    async def menu_cmd(event):
        await _send_menu(event)

    @client.on(user_events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}panel$"))
    async def panel_cmd(event):
        await _send_menu(event)

    if UI_ENABLED and BOT_TOKEN:
        # Bot accounts are required for Telegram callback/reply-markup buttons.
        # The UserBot remains the privileged execution account.
        _bot = TelegramClient(BOT_SESSION, int(os.getenv("API_ID", "0")), os.getenv("API_HASH", ""), auto_reconnect=True, flood_sleep_threshold=60)

        @(_bot.on(events.CallbackQuery))
        async def _callback(event):
            owner = OWNER_ID if OWNER_ID > 0 else await my_id(_user_client)
            if event.sender_id != owner:
                await event.answer("⛔ این منو فقط برای صاحب سلف است.", alert=True)
                return

            data = event.data.decode("utf-8", errors="ignore") if event.data else ""
            if data == "ui:home":
                await event.edit(_home_text(), parse_mode="html", buttons=_home_buttons())
                return
            if data.startswith("ui:sec:"):
                key = data.split(":", 2)[2]
                if key not in SECTIONS:
                    await event.answer("بخش ناشناخته است.", alert=True)
                    return
                await event.edit(_section_text(key), parse_mode="html", buttons=_section_buttons(key))
                return
            if data == "ui:about":
                await event.edit(_about_text(), parse_mode="html", buttons=_nav_buttons())
                return
            if data == "ui:helpfile":
                help_path = Path(__file__).resolve().parents[1] / "docs" / "HELP.txt"
                await _bot.send_file(event.chat_id, help_path, caption="🧩 Hāpoyi UserBot — Help.txt")
                await event.answer("Help.txt ارسال شد ✅")
                return
            if data == "ui:system":
                await event.edit(_system_text(), parse_mode="html", buttons=_nav_buttons())
                return
            if data == "ui:market":
                await event.answer("در حال دریافت قیمت‌ها…")
                await event.edit(await _render_market(), parse_mode="html", buttons=_nav_buttons())
                return
            if data == "ui:quick":
                await event.edit("<b>💵 قیمت سریع</b>\n\nیک دارایی را انتخاب کن:", parse_mode="html", buttons=_quick_buttons())
                return
            if data.startswith("ui:q:"):
                symbol = data.split(":", 2)[2]
                provider = MarketProvider()
                try:
                    if symbol == "USD":
                        fx = FXProvider(cache_seconds=60)
                        irr = await fx.usd_to_irr()
                        text = f"<b>💵 دلار / USD</b>\n\n🇮🇷 {irr / 10:,.0f} تومان\n\n🕐 {_now()}"
                    else:
                        q = await provider.quote(symbol)
                        toman = f"{q.toman:,.0f} تومان" if q.toman is not None else "—"
                        change = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
                        text = (
                            f"<b>🪙 {q.symbol}</b>\n\n"
                            f"💵 USD: ${q.usd:,.8f}\n"
                            f"🇮🇷 Toman: {toman}\n"
                            f"📈 24H: {change}\n"
                            f"🕐 {_now()}"
                        )
                except Exception as exc:
                    text = f"❌ دریافت قیمت ناموفق بود: <code>{exc.__class__.__name__}</code>"
                await event.edit(text, parse_mode="html", buttons=_quick_buttons())
                return
            await event.answer("دکمهٔ نامعتبر.", alert=True)

        try:
            await _bot.start(bot_token=BOT_TOKEN)
            log.info("Assistant UI bot started")
        except Exception as exc:
            log.error("Assistant UI bot failed to start: %s: %s", exc.__class__.__name__, exc)
            try:
                await _bot.disconnect()
            except Exception:
                pass
            _bot = None
    elif UI_ENABLED:
        log.info("Assistant UI disabled because BOT_TOKEN is not configured")


async def shutdown() -> None:
    global _bot
    if _bot is not None:
        try:
            await _bot.disconnect()
        except Exception:
            log.exception("Failed to disconnect assistant UI bot")
        finally:
            _bot = None
