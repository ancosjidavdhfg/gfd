from __future__ import annotations

import os
import random
import re
import time
from datetime import datetime, timezone

from core.identity import my_id
from telethon import events

from core.permissions import resolve_target
from utils.targets import target_label

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."

DEFAULT_ENEMY_REPLIES = [
    "تروخدا از ما بکش بیرون 😭",
    "داداش یکم فاصله لطفاً 😂",
    "باز تو؟ 😐",
    "من با شما کاری ندارم 😭",
    "لطفاً مزاحم نشو 😂",
    "اعصاب ندارم، بعداً بیا 😶",
    "پیامت رسید، جواب قلبی ندارم 😭",
    "برو یه دور دیگه بیا 😐",
    "درخواستت رد شد 😂",
    "من الان در حالت بی‌توجهی‌ام.",
    "لطفاً از این چت عبور کنید 😭",
    "هنوزم دشمنی؟ 😂",
    "فاصله اجتماعی لطفاً.",
    "بهتره سایلنت کنیم همدیگه رو 😐",
    "پیام دریافت شد، علاقه دریافت نشد 😂",
    "تروخدا دوباره شروع نکن 😭",
    "من وانمود می‌کنم این پیام رو ندیدم.",
    "دشمنی با موفقیت ثبت شد ✅",
    "جواب این یکی رو سیستم انتخاب کرد 😂",
    "بعدی! 😐",
]

DEFAULT_FRIEND_REPLIES = [
    "❤️ داداشی",
    "قربونت برم 😄",
    "دمت گرم 🫶",
    "عشقی ❤️",
    "مرسی رفیق 😎",
    "پایتم داداش.",
    "فدات 😄",
    "دمت گرم که هستی ❤️",
    "رفیق خودمی.",
    "❤️❤️",
    "دمت گرم که یادم بودی 😄",
    "بگو ببینم چی شده رفیق.",
    "با تو همیشه پایه‌ام.",
    "مرام داری ❤️",
    "آفرین رفیق 😎",
    "قربون مرامت.",
    "رفاقت برقرار ❤️",
    "تو دیگه خودی‌ای.",
    "دمت گرم که اومدی.",
    "❤️ رفیق قدیمی منی.",
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def setup(client, db):
    cooldowns: dict[tuple[int, int, str], float] = {}
    seeded: set[int] = set()

    async def ensure_defaults(owner_id: int) -> None:
        if owner_id in seeded:
            return
        for kind, values in (("enemy", DEFAULT_ENEMY_REPLIES), ("friend", DEFAULT_FRIEND_REPLIES)):
            row = await db.fetchone(
                "SELECT COUNT(*) AS n FROM relation_replies WHERE owner_id=? AND kind=?",
                (owner_id, kind),
            )
            if not row or row["n"] == 0:
                for value in values:
                    await db.execute(
                        "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
                        (owner_id, kind, value, _now()),
                    )
        seeded.add(owner_id)

    async def _target(event, raw: str | None):
        try:
            return await resolve_target(event, raw)
        except Exception:
            return None

    def _user_id(target) -> int:
        return int(getattr(target, "id", target))

    async def _set_relation(event, kind: str, target, enabled: bool = True):
        owner = (await my_id(client))
        uid = _user_id(target)
        if uid == owner:
            return await event.reply("❌ نمی‌شود خودت را دوست/دشمن تنظیم کرد.")
        if enabled:
            await db.execute("DELETE FROM relations WHERE owner_id=? AND user_id=?", (owner, uid))
            await db.execute(
                "INSERT INTO relations(owner_id,user_id,kind,enabled,cooldown_seconds,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                (owner, uid, kind, 1, 8.0, _now(), _now()),
            )
            label = target_label(target)
            return await event.reply(f"✅ {label} به لیست {kind} اضافه شد.")
        await db.execute("DELETE FROM relations WHERE owner_id=? AND user_id=? AND kind=?", (owner, uid, kind))
        return await event.reply("✅ حذف شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:friend|دوست)\s+(add|del|remove|list|on|off)(?:\s+(\S+))?$"))
    async def friend_cmd(event):
        action, raw = event.pattern_match.group(1), event.pattern_match.group(2)
        owner = (await my_id(client))
        await ensure_defaults(owner)
        if action == "list":
            rows = await db.fetchall("SELECT user_id,enabled,cooldown_seconds FROM relations WHERE owner_id=? AND kind='friend' ORDER BY user_id", (owner,))
            if not rows:
                return await event.reply("❤️ لیست دوست‌ها خالی است.")
            return await event.reply("❤️ Friend List\n" + "\n".join(f"• {r['user_id']} | {'ON' if r['enabled'] else 'OFF'} | cooldown={r['cooldown_seconds']}s" for r in rows))
        if not raw:
            return await event.reply(f"مثال: {PREFIX}friend add @username یا روی پیامش Reply کن.")
        target = await _target(event, raw)
        if target is None:
            return await event.reply("❌ کاربر پیدا نشد.")
        uid = _user_id(target)
        if action in {"del", "remove"}:
            return await _set_relation(event, "friend", target, False)
        if action == "on":
            await db.execute("UPDATE relations SET enabled=1,updated_at=? WHERE owner_id=? AND user_id=? AND kind='friend'", (_now(), owner, uid))
            return await event.reply("✅ پاسخ‌گویی دوست روشن شد.")
        if action == "off":
            await db.execute("UPDATE relations SET enabled=0,updated_at=? WHERE owner_id=? AND user_id=? AND kind='friend'", (_now(), owner, uid))
            return await event.reply("⏸ پاسخ‌گویی دوست خاموش شد.")
        return await _set_relation(event, "friend", target, True)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:enemy|دشمن)\s+(add|del|remove|list|on|off)(?:\s+(\S+))?$"))
    async def enemy_cmd(event):
        action, raw = event.pattern_match.group(1), event.pattern_match.group(2)
        owner = (await my_id(client))
        await ensure_defaults(owner)
        if action == "list":
            rows = await db.fetchall("SELECT user_id,enabled,cooldown_seconds FROM relations WHERE owner_id=? AND kind='enemy' ORDER BY user_id", (owner,))
            if not rows:
                return await event.reply("😈 لیست دشمن‌ها خالی است.")
            return await event.reply("😈 Enemy List\n" + "\n".join(f"• {r['user_id']} | {'ON' if r['enabled'] else 'OFF'} | cooldown={r['cooldown_seconds']}s" for r in rows))
        if not raw:
            return await event.reply(f"مثال: {PREFIX}enemy add @username یا روی پیامش Reply کن.")
        target = await _target(event, raw)
        if target is None:
            return await event.reply("❌ کاربر پیدا نشد.")
        uid = _user_id(target)
        if action in {"del", "remove"}:
            return await _set_relation(event, "enemy", target, False)
        if action == "on":
            await db.execute("UPDATE relations SET enabled=1,updated_at=? WHERE owner_id=? AND user_id=? AND kind='enemy'", (_now(), owner, uid))
            return await event.reply("✅ پاسخ‌گویی دشمن روشن شد.")
        if action == "off":
            await db.execute("UPDATE relations SET enabled=0,updated_at=? WHERE owner_id=? AND user_id=? AND kind='enemy'", (_now(), owner, uid))
            return await event.reply("⏸ پاسخ‌گویی دشمن خاموش شد.")
        return await _set_relation(event, "enemy", target, True)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:friend|دوست)\s+reply\s+(.+)$"))
    async def friend_reply_add(event):
        owner = (await my_id(client))
        await ensure_defaults(owner)
        text = event.pattern_match.group(1).strip()
        if not text or len(text) > 500:
            return await event.reply("❌ پاسخ باید بین 1 تا 500 کاراکتر باشد.")
        await db.execute(
            "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
            (owner, "friend", text, _now()),
        )
        await event.reply("✅ پاسخ جدید برای دوست‌ها اضافه شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:enemy|دشمن)\s+reply\s+(.+)$"))
    async def enemy_reply_add(event):
        owner = (await my_id(client))
        await ensure_defaults(owner)
        text = event.pattern_match.group(1).strip()
        if not text or len(text) > 500:
            return await event.reply("❌ پاسخ باید بین 1 تا 500 کاراکتر باشد.")
        await db.execute(
            "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
            (owner, "enemy", text, _now()),
        )
        await event.reply("✅ پاسخ جدید برای دشمن‌ها اضافه شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}relation\s+reply\s+(friend|enemy)\s+(.+)$"))
    async def relation_reply_alias(event):
        kind = event.pattern_match.group(1)
        text = event.pattern_match.group(2).strip()
        owner = (await my_id(client))
        await ensure_defaults(owner)
        if not text or len(text) > 500:
            return await event.reply("❌ پاسخ باید بین 1 تا 500 کاراکتر باشد.")
        await db.execute(
            "INSERT INTO relation_replies(owner_id,kind,reply_text,created_at) VALUES(?,?,?,?)",
            (owner, kind, text, _now()),
        )
        await event.reply(f"✅ پاسخ جدید برای {kind} اضافه شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}relation\s+cooldown\s+(friend|enemy)\s+(\d+(?:\.\d+)?)$"))
    async def relation_cooldown(event):
        kind = event.pattern_match.group(1)
        seconds = max(2.0, min(float(event.pattern_match.group(2)), 3600.0))
        owner = (await my_id(client))
        await db.execute("UPDATE relations SET cooldown_seconds=?,updated_at=? WHERE owner_id=? AND kind=?", (seconds, _now(), owner, kind))
        await event.reply(f"✅ cooldown برای {kind} روی {seconds:g} ثانیه تنظیم شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}relation\s+(replies|stats|clear)(?:\s+(friend|enemy))?$"))
    async def relation_tools(event):
        action, kind = event.pattern_match.group(1), event.pattern_match.group(2)
        owner = (await my_id(client))
        await ensure_defaults(owner)
        if action == "clear":
            if not kind:
                return await event.reply("❌ نوع را مشخص کن: friend یا enemy")
            await db.execute("DELETE FROM relation_replies WHERE owner_id=? AND kind=?", (owner, kind))
            seeded.discard(owner)
            await ensure_defaults(owner)
            return await event.reply("✅ پاسخ‌ها پاک و به پیش‌فرض برگردانده شدند.")
        if action == "stats":
            rel = await db.fetchall("SELECT kind,COUNT(*) AS n FROM relations WHERE owner_id=? GROUP BY kind", (owner,))
            rep = await db.fetchall("SELECT kind,COUNT(*) AS n FROM relation_replies WHERE owner_id=? AND enabled=1 GROUP BY kind", (owner,))
            counts = {r['kind']: r['n'] for r in rel}
            reps = {r['kind']: r['n'] for r in rep}
            return await event.reply(f"🤝 Relations\n❤️ friend={counts.get('friend',0)} | replies={reps.get('friend',0)}\n😈 enemy={counts.get('enemy',0)} | replies={reps.get('enemy',0)}")
        rows = await db.fetchall("SELECT kind,reply_text FROM relation_replies WHERE owner_id=? AND enabled=1 ORDER BY rowid", (owner,))
        if kind:
            rows = [r for r in rows if r["kind"] == kind]
        if not rows:
            return await event.reply("خالی است.")
        text = "\n".join(f"{i+1}. [{r['kind']}] {r['reply_text']}" for i, r in enumerate(rows))
        await event.reply("🗂 Reply Pool\n" + text[:3900])

    @client.on(events.NewMessage)
    async def relation_responder(event):
        if event.out or not event.sender_id or not event.raw_text:
            return
        if event.raw_text.startswith(PREFIX):
            return
        owner = (await my_id(client))
        await ensure_defaults(owner)
        row = await db.fetchone(
            "SELECT kind,enabled,cooldown_seconds FROM relations WHERE owner_id=? AND user_id=?",
            (owner, event.sender_id),
        )
        if not row or not row["enabled"]:
            return
        key = (int(event.chat_id), int(event.sender_id), row["kind"])
        now = time.monotonic()
        cooldown = max(2.0, float(row["cooldown_seconds"] or 8.0))
        if now - cooldowns.get(key, 0) < cooldown:
            return
        replies = await db.fetchall(
            "SELECT reply_text FROM relation_replies WHERE owner_id=? AND kind=? AND enabled=1",
            (owner, row["kind"]),
        )
        if not replies:
            return
        answer = random.choice(replies)["reply_text"]
        cooldowns[key] = now
        try:
            await client.send_message(event.chat_id, answer)
        except Exception:
            pass
