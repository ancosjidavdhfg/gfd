from __future__ import annotations

import os
from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}comment\s+(\S+)\s+(.+)$"))
    async def comment(event):
        channel, text = event.pattern_match.group(1), event.pattern_match.group(2)
        try:
            entity = await client.get_entity(channel)
            posts = await client.get_messages(entity, limit=1)
            if not posts:
                return await event.reply("❌ پستی پیدا نشد.")
            await client.send_message(entity, text, comment_to=posts[0].id)
            await event.reply(f"✅ روی آخرین پست {channel} کامنت گذاشته شد.")
        except Exception as exc:
            await event.reply(f"❌ Comment failed: {exc.__class__.__name__}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}comments\s+(\S+)\s+(\d+)$"))
    async def comments(event):
        channel, post_id = event.pattern_match.group(1), int(event.pattern_match.group(2))
        entity = await client.get_entity(channel)
        rows=[]
        async for msg in client.iter_messages(entity, reply_to=post_id, limit=30):
            rows.append(f"• {msg.sender_id}: {msg.raw_text[:100]}")
        await event.reply("💬 Comments\n" + "\n".join(rows) if rows else "💬 بدون کامنت")
