from __future__ import annotations

import os
import re

from telethon import events
from telethon.errors import RPCError
from telethon.tl.types import ChannelParticipantsAdmins

from core.actions import UnsupportedChat, edit_banned
from core.identity import my_id
from core.permissions import (
    ensure_target_not_self,
    explain_error,
    get_real_reply,
    require_group_right,
    resolve_target,
    target_is_admin,
)
from utils.formatting import parse_duration
from utils.rights import MIN_RESTRICT_SECONDS, ban_rights, mute_rights, open_rights
from utils.targets import target_label

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)


def setup(client, db):
    _UNSET = object()

    async def prepare(event, right: str = "ban_users", *, need_target: bool = True, protect_admin: bool = False, explicit=_UNSET):
        """Common checks. Returns (target, error_text). On error the caller must reply with it."""
        if not event.is_group:
            return None, "❌ این دستور فقط در گروه/سوپرگروه قابل استفاده است."
        perm = await require_group_right(client, event.chat_id, right)
        if not perm.allowed:
            return None, "❌ انجام نشد: " + perm.reason
        if not need_target:
            return None, None
        if explicit is _UNSET:
            explicit = event.pattern_match.groupdict().get("target")
        user = await resolve_target(event, explicit)
        if user is None:
            return None, "❌ ریپلای کن یا username/ID معتبر بده (کاربر پیدا نشد)."
        safe = await ensure_target_not_self(client, user)
        if not safe.allowed:
            return None, "❌ " + safe.reason
        if protect_admin and await target_is_admin(client, event.chat_id, user):
            return None, "❌ انجام نشد: هدف ادمین/مالک گروه است."
        return user, None

    async def run(event, user, rights, ok_text: str, fail_label: str):
        try:
            await edit_banned(client, event, user, rights)
        except UnsupportedChat as exc:
            return await event.reply(f"❌ {fail_label} نشد: {exc}")
        except RPCError as exc:
            return await event.reply(f"❌ {fail_label} نشد: {explain_error(exc)}")
        await event.reply(ok_text)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}ban(?:\s+(?P<target>\S+))?$"))
    async def ban(event):
        user, err = await prepare(event, "ban_users", protect_admin=True)
        if err:
            return await event.reply(err)
        await run(event, user, ban_rights(), f"🔨 {target_label(user)} با موفقیت بن شد.", "بن")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}unban(?:\s+(?P<target>\S+))?$"))
    async def unban(event):
        user, err = await prepare(event, "ban_users")
        if err:
            return await event.reply(err)
        await run(event, user, open_rights(), f"✅ {target_label(user)} با موفقیت آن‌بن شد.", "آن‌بن")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}kick(?:\s+(?P<target>\S+))?$"))
    async def kick(event):
        user, err = await prepare(event, "ban_users", protect_admin=True)
        if err:
            return await event.reply(err)
        try:
            await edit_banned(client, event, user, ban_rights())
            try:
                await edit_banned(client, event, user, open_rights())  # lets the user rejoin
            except (RPCError, UnsupportedChat):
                pass
        except UnsupportedChat as exc:
            return await event.reply(f"❌ کیک نشد: {exc}")
        except RPCError as exc:
            return await event.reply(f"❌ کیک نشد: {explain_error(exc)}")
        await event.reply(f"👢 {target_label(user)} با موفقیت کیک شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}mute(?:\s+(?P<target>@?\w+|-?\d+))?(?:\s+(?P<duration>\d+(?:\.\d+)?[smhdwSMHDW]))?$"))
    async def mute(event):
        groups = event.pattern_match.groupdict()
        explicit, duration = groups.get("target"), groups.get("duration")
        if explicit and not duration and re.fullmatch(r"\d+(?:\.\d+)?[smhdwSMHDW]", explicit):
            # ".mute 10m" (as a reply): the single argument is the duration, not a user.
            explicit, duration = None, explicit
        user, err = await prepare(event, "ban_users", protect_admin=True, explicit=explicit)
        if err:
            return await event.reply(err)
        seconds = None
        if duration:
            try:
                seconds = parse_duration(duration)
            except ValueError as exc:
                return await event.reply("❌ " + str(exc))
            if seconds < MIN_RESTRICT_SECONDS:
                # Telegram turns an until_date < 30s into a PERMANENT restriction.
                return await event.reply(f"❌ حداقل مدت mute {MIN_RESTRICT_SECONDS} ثانیه است (کمتر از آن توسط تلگرام دائمی می‌شود).")
        await run(event, user, mute_rights(seconds), f"🔇 {target_label(user)} با موفقیت mute شد" + (f" برای {duration}." if duration else " (دائمی)."), "میوت")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}unmute(?:\s+(?P<target>\S+))?$"))
    async def unmute(event):
        user, err = await prepare(event, "ban_users")
        if err:
            return await event.reply(err)
        await run(event, user, open_rights(), f"🔊 {target_label(user)} با موفقیت unmute شد.", "آن‌میوت")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}del$"))
    async def delete(event):
        reply = await get_real_reply(event)
        if reply is None:
            return await event.reply("❌ روی پیام Reply کن.")
        mine = reply.sender_id == await my_id(client)
        if event.is_group and not mine:
            perm = await require_group_right(client, event.chat_id, "delete_messages")
            if not perm.allowed:
                return await event.reply("❌ انجام نشد: " + perm.reason)
        try:
            await client.delete_messages(event.chat_id, [reply.id, event.id])
        except RPCError as exc:
            await event.reply("❌ حذف نشد: " + explain_error(exc))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}purge(?:\s+(\d+))?$"))
    async def purge(event):
        if event.is_group:
            perm = await require_group_right(client, event.chat_id, "delete_messages")
            if not perm.allowed:
                return await event.reply("❌ انجام نشد: " + perm.reason)
        reply = await get_real_reply(event)
        if reply is not None:
            ids = [m.id async for m in client.iter_messages(event.chat_id, min_id=reply.id - 1, limit=500)]
        else:
            n = max(1, min(int(event.pattern_match.group(1) or 20), 500))
            ids = [m.id async for m in client.iter_messages(event.chat_id, limit=n + 1)]
        if event.id not in ids:
            ids.append(event.id)
        try:
            await client.delete_messages(event.chat_id, ids)
        except RPCError as exc:
            await event.reply("❌ پاکسازی نشد: " + explain_error(exc))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}pin$"))
    async def pin(event):
        if event.is_group:
            perm = await require_group_right(client, event.chat_id, "pin_messages")
            if not perm.allowed:
                return await event.reply("❌ انجام نشد: " + perm.reason)
        reply = await get_real_reply(event)
        if reply is None:
            return await event.reply("❌ روی پیام Reply کن.")
        try:
            await client.pin_message(event.chat_id, reply.id, notify=False)
        except RPCError as exc:
            return await event.reply("❌ پین نشد: " + explain_error(exc))
        await event.delete()

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}unpin(?:\s+(all))?$"))
    async def unpin(event):
        if event.is_group:
            perm = await require_group_right(client, event.chat_id, "pin_messages")
            if not perm.allowed:
                return await event.reply("❌ انجام نشد: " + perm.reason)
        reply = await get_real_reply(event)
        try:
            if reply is not None:
                await client.unpin_message(event.chat_id, reply.id)
            elif event.pattern_match.group(1):
                await client.unpin_message(event.chat_id)
            else:
                return await event.reply(f"❌ روی پیام Reply کن یا `{PREFIX}unpin all` بزن.")
        except RPCError as exc:
            return await event.reply("❌ آن‌پین نشد: " + explain_error(exc))
        await event.delete()

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}admins$"))
    async def admins(event):
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        rows = []
        async for user in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
            name = " ".join(x for x in [user.first_name, user.last_name] if x).strip() or str(user.id)
            rows.append(f"• {name} — @{user.username}" if user.username else f"• {name} — {user.id}")
        await event.reply("👮 Admins\n" + "\n".join(rows[:100]) if rows else "👮 ادمینی پیدا نشد.")
