from __future__ import annotations

import os
import time
from collections import defaultdict

from telethon import events
from telethon.errors import FloodWaitError, PeerFloodError, SlowModeWaitError

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    # Runtime-only circuit breaker: if Telegram reports a flood condition,
    # stop high-frequency automation in that chat until the cooldown expires.
    blocked_until: dict[int, float] = defaultdict(float)

    async def state(chat_id: int) -> dict:
        return await db.get_chat_settings(chat_id)

    async def set_state(chat_id: int, enabled: bool):
        return await db.update_chat_settings(chat_id, safety_guard=enabled)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}safety(?:\s+(on|off|status))?$"))
    async def safety(event):
        action = event.pattern_match.group(1) or "status"
        if action == "on":
            await set_state(event.chat_id, True)
            return await event.reply("🛡 Safety Guard روشن شد.\nFloodWait/SlowMode باعث توقف خودکار عملیات پرتکرار می‌شود.")
        if action == "off":
            await set_state(event.chat_id, False)
            return await event.reply("⏸ Safety Guard خاموش شد.")
        cfg = await state(event.chat_id)
        remain = max(0, int(blocked_until.get(event.chat_id, 0) - time.monotonic()))
        return await event.reply(
            f"🛡 Safety Guard: {'ON' if cfg.get('safety_guard', True) else 'OFF'}\n"
            f"Circuit breaker: {'blocked '+str(remain)+'s' if remain else 'ready'}\n"
            "این ماژول برای دورزدن تشخیص تلگرام نیست؛ برای جلوگیری از تولید ترافیک اسپمی است."
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}floodguard(?:\s+(on|off|status))?$"))
    async def floodguard_alias(event):
        action = event.pattern_match.group(1) or "status"
        cfg = await state(event.chat_id)
        if action == "on":
            await set_state(event.chat_id, True)
        elif action == "off":
            await set_state(event.chat_id, False)
        cfg = await state(event.chat_id)
        remain = max(0, int(blocked_until.get(event.chat_id, 0) - time.monotonic()))
        await event.reply(f"🧯 FloodGuard {'ON' if cfg.get('safety_guard', True) else 'OFF'} | breaker={'blocked '+str(remain)+'s' if remain else 'ready'}")

    async def allow(chat_id: int) -> bool:
        cfg = await state(chat_id)
        return bool(cfg.get("safety_guard", True)) and time.monotonic() >= blocked_until.get(chat_id, 0)

    async def trip(chat_id: int, seconds: int, reason: str):
        blocked_until[chat_id] = max(blocked_until.get(chat_id, 0), time.monotonic() + seconds)
        await db.update_chat_settings(chat_id, last_flood_reason=reason, flood_breaker_seconds=seconds)

    # Expose helpers on the client for modules such as Casino.
    client._hapoyi_safety_allow = allow
    client._hapoyi_safety_trip = trip
    client._hapoyi_safety_blocked_until = blocked_until

    @client.on(events.NewMessage)
    async def flood_error_guard(event):
        # This handler intentionally does not send anything on ordinary traffic.
        return

    return None


class SafetyTrip:
    @staticmethod
    def seconds(exc) -> int:
        if isinstance(exc, (FloodWaitError, SlowModeWaitError)):
            return max(2, int(getattr(exc, "seconds", 5)))
        if isinstance(exc, PeerFloodError):
            return 300
        return 10
