from __future__ import annotations

import asyncio
import os
import random
import re
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone

from core.identity import my_id
from telethon import events, types
from telethon.errors import FloodWaitError, PeerFloodError, RPCError, SlowModeWaitError

from modules.safety_guard import SafetyTrip

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
DICE_TARGETS = {"🎲": 6, "🎯": 6, "🎳": 6, "🏀": 5, "⚽": 5, "🎰": 64}
SMART_WORDS = {"smart", "hooshmad", "هوشمند", "هوشماد", "smartmode"}

# Telegram documents the slot machine as 64 values made of three 2-bit reel values.
# Telegram Desktop's implementation maps those values to bar, berries, lemon, seven.
SLOT_SYMBOLS = {
    "bar": "BAR",
    "grape": "🍇",
    "grapes": "🍇",
    "berry": "🍇",
    "berries": "🍇",
    "lemon": "🍋",
    "seven": "7️⃣",
}
SLOT_CANONICAL = ("bar", "grape", "lemon", "seven")
SYMBOL_ALIASES = {
    "bar": "bar", "➖": "bar", "-": "bar", "بار": "bar",
    "grape": "grape", "grapes": "grape", "berry": "grape", "berries": "grape", "🍇": "grape", "انگور": "grape",
    "lemon": "lemon", "🍋": "lemon", "لیمو": "lemon",
    "seven": "seven", "7": "seven", "7️⃣": "seven", "هفت": "seven", "سه هفت": "seven",
}
NUMBER_WORDS = {
    "یک": 1, "یه": 1, "یکتا": 1, "one": 1,
    "دو": 2, "دوتا": 2, "دو تا": 2, "two": 2,
    "سه": 3, "سه تا": 3, "three": 3,
}


def slot_combo(value: int) -> tuple[str, str, str]:
    """Decode Telegram 🎰 value (1..64) into left/middle/right canonical symbols."""
    if not 1 <= int(value) <= 64:
        raise ValueError("slot value must be 1..64")
    n = int(value) - 1
    out: list[str] = []
    for _ in range(3):
        out.append(SLOT_CANONICAL[(n & 3)])
        n >>= 2
    return tuple(out)  # left, middle, right


def slot_value(combo: tuple[str, str, str]) -> int:
    if len(combo) != 3 or any(x not in SLOT_CANONICAL for x in combo):
        raise ValueError("combo must contain exactly three valid symbols")
    digit = {name: idx for idx, name in enumerate(SLOT_CANONICAL)}
    value0 = digit[combo[0]] | (digit[combo[1]] << 2) | (digit[combo[2]] << 4)
    return value0 + 1


def slot_display(combo: tuple[str, str, str]) -> str:
    return " | ".join(SLOT_SYMBOLS[x] for x in combo)


def all_slot_values() -> dict[int, tuple[str, str, str]]:
    return {value: slot_combo(value) for value in range(1, 65)}


def slot_is_triple(combo: tuple[str, str, str]) -> bool:
    return combo[0] == combo[1] == combo[2]


def slot_is_pair(combo: tuple[str, str, str]) -> bool:
    return len(set(combo)) == 2


def slot_matches(combo: tuple[str, str, str], kind: str) -> bool:
    """Predicate used by the casino target parser."""
    c0, c1, c2 = combo
    counts = Counter(combo)
    k = kind.strip().lower()
    if k in {"any", "random", "all"}:
        return True
    if k in {"triple", "three", "سه", "سه تا", "سه‌تایی", "سه تایی", "jackpot", "جکپات"}:
        return slot_is_triple(combo)
    if k in {"pair", "دو", "دو تایی", "جفت", "double"}:
        return slot_is_pair(combo)
    if k in {"all-different", "different", "متفاوت", "همه متفاوت"}:
        return len(set(combo)) == 3
    if k in {"any-seven", "seven", "هفت", "یک هفت", "هفت دار"}:
        return "seven" in combo
    if k in {"center-seven", "middle-seven", "mid-seven", "middle7", "هفت وسط", "وسط هفت"}:
        return c1 == "seven"
    if k in {"left-seven", "هفت چپ", "اول هفت"}:
        return c0 == "seven"
    if k in {"right-seven", "هفت راست", "آخر هفت"}:
        return c2 == "seven"
    if k in {"no-seven", "بدون هفت"}:
        return "seven" not in combo
    if k in {"lemon", "lemons", "لیمو"}:
        return "lemon" in combo
    if k in {"grape", "grapes", "انگور"}:
        return "grape" in combo
    if k in {"bar", "بار"}:
        return "bar" in combo
    return False


def parse_slot_target(raw: str) -> tuple[str, object, str]:
    """Return (mode, target, human_label). Modes: value|exact|predicate."""
    text = raw.strip()
    low = text.lower()
    compact = re.sub(r"\s+", " ", low)

    # Direct numeric outcome.
    if re.fullmatch(r"\d{1,2}", compact):
        value = int(compact)
        if 1 <= value <= 64:
            combo = slot_combo(value)
            return "value", value, f"#{value} ({slot_display(combo)})"
        if value == 777:
            return "value", 64, "777 / سه‌هفت (64)"
        raise ValueError("مقدار 🎰 باید بین 1 تا 64 باشد؛ 777 هم به‌عنوان سه‌هفت پذیرفته می‌شود.")

    # Exact symbol sequence, accepting symbols separated by spaces, commas, or |.
    tokens = [x for x in re.split(r"[|,\s]+", compact) if x]
    canonical: list[str] = []
    for token in tokens:
        t = SYMBOL_ALIASES.get(token)
        if t:
            canonical.append(t)
    if len(canonical) == 3 and len(tokens) == 3:
        combo = tuple(canonical)  # type: ignore[assignment]
        return "exact", combo, slot_display(combo)

    # Friendly "2 lemon 1 seven" / "دو تا لیمو یک هفت" counts.
    count_pattern = re.compile(r"(?:^|\s)(\d+|یک|یه|دو|سه)(?:\s*تا)?\s*(bar|grape|grapes|berry|berries|lemon|seven|بار|انگور|لیمو|هفت|7️⃣|🍇|🍋|➖)(?=\s|$)")
    pairs = count_pattern.findall(compact)
    if pairs:
        expanded: list[str] = []
        matched_text = ""
        for count_raw, symbol_raw in pairs:
            count = NUMBER_WORDS.get(count_raw, None)
            if count is None:
                count = int(count_raw)
            symbol = SYMBOL_ALIASES[symbol_raw]
            expanded.extend([symbol] * count)
            matched_text += f" {count} {symbol}"
        if len(expanded) != 3:
            raise ValueError("ترکیب 🎰 باید دقیقاً ۳ نماد داشته باشد؛ مثلاً `2 lemon 1 seven`.")
        # Order is unspecified for count mode. It matches any permutation with these counts.
        return "counts", Counter(expanded), " + ".join(f"{n}×{SLOT_SYMBOLS[s]}" for s, n in Counter(expanded).items())

    # Named predicates.
    aliases = {
        "jackpot": "triple", "جکپات": "triple", "triple": "triple", "سه تایی": "triple", "سه‌تایی": "triple",
        "any-seven": "any-seven", "any seven": "any-seven", "هر هفت": "any-seven", "هفت دار": "any-seven",
        "center-seven": "center-seven", "middle-seven": "center-seven", "middle7": "center-seven", "هفت وسط": "center-seven", "وسط هفت": "center-seven",
        "left-seven": "left-seven", "هفت چپ": "left-seven", "اول هفت": "left-seven",
        "right-seven": "right-seven", "هفت راست": "right-seven", "آخر هفت": "right-seven",
        "pair": "pair", "double": "pair", "جفت": "pair", "دو تایی": "pair",
        "different": "all-different", "all-different": "all-different", "همه متفاوت": "all-different",
        "no-seven": "no-seven", "بدون هفت": "no-seven",
        "lemon": "lemon", "lemon any": "lemon", "لیمو": "lemon",
        "grape": "grape", "انگور": "grape",
        "bar": "bar", "بار": "bar",
    }
    pred = aliases.get(compact)
    if pred:
        if pred == "triple":
            return "predicate", "triple", "هر سه یکی (Jackpot)"
        return "predicate", pred, pred

    # "triple lemon", "سه لیمو" etc.
    for prefix in ("triple ", "three ", "سه ", "سه تا ", "سه‌تا "):
        if compact.startswith(prefix):
            sym = SYMBOL_ALIASES.get(compact[len(prefix):].strip())
            if sym:
                return "exact", (sym, sym, sym), f"سه‌تایی {SLOT_SYMBOLS[sym]}"

    raise ValueError("هدف 🎰 شناخته نشد. نمونه: `777`, `43`, `lemon lemon lemon`, `2 lemon 1 seven`, `center-seven`, `jackpot`.")


@dataclass
class GameResult:
    game: str
    value: int | str
    label: str
    won: bool = True
    points: int = 0


async def setup(client, db):
    global PREFIX
    PREFIX = (await db.get_kv("command_prefix", ".")) or "."
    active: dict[tuple[int, int], asyncio.Task] = {}

    async def score(owner: int, chat: int, game: str, points: int) -> None:
        await db.execute(
            """CREATE TABLE IF NOT EXISTS game_scores (
                owner_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                game TEXT NOT NULL,
                wins INTEGER NOT NULL DEFAULT 0,
                plays INTEGER NOT NULL DEFAULT 0,
                points INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,
                PRIMARY KEY(owner_id, chat_id, game)
            )"""
        )
        now = datetime.now(timezone.utc).isoformat()
        await db.execute(
            """INSERT INTO game_scores(owner_id,chat_id,game,wins,plays,points,updated_at)
               VALUES(?,?,?,?,?,?,?)
               ON CONFLICT(owner_id,chat_id,game) DO UPDATE SET
                 wins=game_scores.wins+excluded.wins,
                 plays=game_scores.plays+excluded.plays,
                 points=game_scores.points+excluded.points,
                 updated_at=excluded.updated_at""",
            (owner, chat, game, 1 if points > 0 else 0, 1, points, now),
        )

    async def cancel(event) -> bool:
        key = ((await my_id(client)), event.chat_id or 0)
        task = active.pop(key, None)
        if not task:
            return False
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        return True

    async def send_dice_until(event, emoji: str, predicate, description: str, *, smart: bool, max_rolls: int):
        key = ((await my_id(client)), event.chat_id or 0)
        if key in active and not active[key].done():
            await event.reply("⚠️ یک بازی در همین چت در حال اجراست؛ `.game cancel` بزن.")
            return
        if hasattr(client, "_hapoyi_safety_allow") and not await client._hapoyi_safety_allow(event.chat_id):
            await event.reply("🛡️ Safety Guard این چت را موقتاً متوقف کرده است.")
            return

        async def runner():
            final = None
            attempt = 0
            try:
                for attempt in range(1, max_rolls + 1):
                    if hasattr(client, "_hapoyi_safety_allow") and not await client._hapoyi_safety_allow(event.chat_id):
                        break
                    try:
                        msg = await client.send_file(event.chat_id, types.InputMediaDice(emoji))
                    except (FloodWaitError, SlowModeWaitError, PeerFloodError) as exc:
                        wait = SafetyTrip.seconds(exc)
                        if hasattr(client, "_hapoyi_safety_trip"):
                            await client._hapoyi_safety_trip(event.chat_id, wait, exc.__class__.__name__)
                        if wait <= 8:
                            await asyncio.sleep(wait)
                        break
                    await asyncio.sleep(0.9 if smart else 0.65)
                    media = getattr(msg, "media", None)
                    value = getattr(media, "value", None)
                    if value is not None and predicate(value):
                        final = msg
                        break
                    try:
                        await msg.delete()
                    except RPCError:
                        pass
                    if smart:
                        delay = min(2.6, 1.0 + ((attempt - 1) // 8) * 0.15)
                    else:
                        delay = 0.8
                    await asyncio.sleep(delay)

                try:
                    await event.delete()
                except RPCError:
                    pass
                if final is not None:
                    await score((await my_id(client)), event.chat_id or 0, "dice" if emoji != "🎰" else "casino", 1)
                    text = f"🎉 پیدا شد!\n🎰 {description}\n🔢 تلاش: {attempt}"
                    if smart:
                        text += "\n🧠 حالت هوشمند"
                    await client.send_message(event.chat_id, text)
                else:
                    await score((await my_id(client)), event.chat_id or 0, "dice" if emoji != "🎰" else "casino", 0)
                    await client.send_message(event.chat_id, "🛑 بازی متوقف شد؛ نتیجه پیدا نشد یا Telegram محدودیت سرعت اعمال کرد.")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                try:
                    await client.send_message(event.chat_id, f"❌ Game error: {exc.__class__.__name__}")
                except Exception:
                    pass
            finally:
                active.pop(key, None)

        task = asyncio.create_task(runner())
        active[key] = task
        try:
            await event.delete()
        except RPCError:
            pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:game\s+)?cancel$"))
    async def game_cancel(event):
        ok = await cancel(event)
        await event.reply("🛑 بازی متوقف شد." if ok else "ℹ️ بازی فعالی نیست.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}game\s+status$"))
    async def game_status(event):
        task = active.get(((await my_id(client)), event.chat_id or 0))
        await event.reply("🎮 بازی فعال است." if task and not task.done() else "🎮 بازی فعالی نیست.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}game\s+list$"))
    async def game_list(event):
        await event.reply(
            "🎮 GAME HUB\n\n"
            "🎰 casino — هر ۶۴ حالت اسلات + جست‌وجوی الگو\n"
            "🎲 dice / 🎯 dart / 🎳 bowling / 🏀 basket / ⚽ football\n"
            "🪙 coin — شیر/خط\n"
            "✂️ rps — سنگ/کاغذ/قیچی\n"
            "🎡 roulette — رولت محلی 0..36\n"
            "🎱 8ball — پاسخ تصادفی\n"
            "🃏 blackjack — یک دست سریع\n"
            "🎯 roll — تاس عددی\n"
            "🧠 choose — انتخاب تصادفی بین گزینه‌ها\n"
            "🏆 game score / leaderboard"
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}casino(?:\s+(.+?))?$"))
    async def casino(event):
        raw = (event.pattern_match.group(1) or "").strip()
        if not raw:
            await event.reply(
                "🎰 Casino\n\n"
                "نمونه‌ها:\n"
                "`.casino 777`\n"
                "`.casino smart 777 100`\n"
                "`.casino lemon lemon lemon`\n"
                "`.casino 2 lemon 1 seven`\n"
                "`.casino lemon seven lemon`\n"
                "`.casino center-seven`\n"
                "`.casino jackpot`\n"
                "`.casino 43`\n"
                "`.casino all` برای جدول کامل ۶۴ حالت\n"
                "`.casino explain 43` برای رمزگشایی"
            )
            return

        parts = raw.split()
        smart = False
        if parts and parts[0].lower() in SMART_WORDS:
            smart = True
            parts = parts[1:]
        if parts and parts[0].lower() in {"all", "list", "لیست", "۶۴"}:
            path = __import__("pathlib").Path(__file__).resolve().parents[1] / "docs" / "SLOT_64.txt"
            await event.reply("📚 جدول تمام ۶۴ حالت 🎰", file=path)
            return
        if parts and parts[0].lower() in {"explain", "decode", "رمزگشایی"}:
            if len(parts) < 2:
                await event.reply("نمونه: `.casino explain 43`")
                return
            try:
                value = 64 if parts[1] == "777" else int(parts[1])
                combo = slot_combo(value)
                await event.reply(f"🎰 {value}\n{slot_display(combo)}")
            except Exception as exc:
                await event.reply(f"❌ {exc}")
            return
        raw_target = " ".join(parts)
        limit = 100
        # Optional max-roll suffix: `<target> <max_rolls>`. For numeric targets the
        # first number must be a valid slot value, while the final number is >64.
        m = re.fullmatch(r"(.+?)\s+(\d{1,4})$", raw_target)
        if m:
            first = m.group(1).strip()
            try:
                first_num = int(first)
            except ValueError:
                first_num = -1
            if (first_num != -1 and 1 <= first_num <= 64 and int(m.group(2)) > 64) or first_num == 777 or first_num == -1:
                raw_target, limit_raw = first, m.group(2)
                limit = max(1, min(int(limit_raw), 500))

        try:
            mode, target, label = parse_slot_target(raw_target)
        except ValueError as exc:
            await event.reply(f"❌ {exc}")
            return

        def predicate(value: int) -> bool:
            combo = slot_combo(value)
            if mode == "value":
                return value == target
            if mode == "exact":
                return combo == target
            if mode == "counts":
                return Counter(combo) == target
            return slot_matches(combo, str(target))

        await send_dice_until(event, "🎰", predicate, label, smart=smart, max_rolls=limit)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}(?:dice|dart|bowling|basket|football)(?:\s+(?:(smart|hooshmad|هوشمند)\s+)?)?(\d+)(?:\s+(\d+))?$"))
    async def other_dice(event):
        smart = bool(event.pattern_match.group(1))
        typ = event.raw_text.split()[0].lstrip(PREFIX).lower()
        target = int(event.pattern_match.group(2))
        max_rolls = max(1, min(int(event.pattern_match.group(3) or 100), 300))
        emoji = {"dice": "🎲", "dart": "🎯", "bowling": "🎳", "basket": "🏀", "football": "⚽"}[typ]
        maximum = DICE_TARGETS[emoji]
        if target < 1 or target > maximum:
            await event.reply(f"❌ برای {emoji} مقدار معتبر {1} تا {maximum} است.")
            return
        await send_dice_until(event, emoji, lambda x: x == target, f"{emoji} = {target}", smart=smart, max_rolls=max_rolls)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}slots?(?:\s+(.+))?$"))
    async def slot_alias(event):
        raw = (event.pattern_match.group(1) or "").strip()
        if not raw:
            await event.reply("🎰 از `.casino` استفاده کن. مثال: `.slots lemon lemon lemon`")
            return
        parts = raw.split()
        smart = False
        if parts and parts[0].lower() in SMART_WORDS:
            smart = True
            parts = parts[1:]
        try:
            mode, target, label = parse_slot_target(" ".join(parts))
        except ValueError as exc:
            await event.reply(f"❌ {exc}")
            return
        def predicate(value: int) -> bool:
            combo = slot_combo(value)
            if mode == "value":
                return value == target
            if mode == "exact":
                return combo == target
            if mode == "counts":
                return Counter(combo) == target
            return slot_matches(combo, str(target))
        await send_dice_until(event, "🎰", predicate, label, smart=smart, max_rolls=100)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}coin$"))
    async def coin(event):
        result = random.choice(["شیر", "خط"])
        await score((await my_id(client)), event.chat_id or 0, "coin", 1)
        await event.edit(f"🪙 {result}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}rps\s+(rock|paper|scissors|سنگ|کاغذ|قیچی)$"))
    async def rps(event):
        raw = event.pattern_match.group(1).lower()
        trans = {"rock": "rock", "سنگ": "rock", "paper": "paper", "کاغذ": "paper", "scissors": "scissors", "قیچی": "scissors"}
        user = trans[raw]
        bot = random.choice(["rock", "paper", "scissors"])
        win = (user, bot) in {("rock", "scissors"), ("paper", "rock"), ("scissors", "paper")}
        result = "مساوی" if user == bot else "بردی 🎉" if win else "باختی 😄"
        await score((await my_id(client)), event.chat_id or 0, "rps", 2 if win else 0)
        await event.edit(f"✂️ تو: {user}\n🤖 من: {bot}\n🏁 {result}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}roulette$"))
    async def roulette(event):
        n = random.randint(0, 36)
        if n == 0:
            color = "🟢 سبز"
        elif n % 2:
            color = "🔴 قرمز"
        else:
            color = "⚫ مشکی"
        await score((await my_id(client)), event.chat_id or 0, "roulette", 1)
        await event.edit(f"🎡 رولت\n\nعدد: <b>{n}</b>\nرنگ: {color}", parse_mode="html")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}8ball(?:\s+(.+))?$"))
    async def eightball(event):
        answers = [
            "قطعاً ✅", "احتمالش زیاده 😎", "بله", "فعلاً بله", "شاید", "نشونه خوبی نیست 😬",
            "نه", "احتمالاً نه", "اصلاً رویش حساب نکن", "ازم نپرس 😂",
        ]
        q = (event.pattern_match.group(1) or "").strip()
        await event.edit(f"🎱 {q + chr(10) if q else ''}<b>{random.choice(answers)}</b>", parse_mode="html")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}roll\s+(\d+)\s*(?:-\s*(\d+))?$"))
    async def roll(event):
        lo = int(event.pattern_match.group(1))
        hi = int(event.pattern_match.group(2) or lo)
        if hi < lo:
            lo, hi = hi, lo
        if hi - lo > 1_000_000:
            await event.reply("❌ بازه بیش از حد بزرگ است.")
            return
        value = random.randint(lo, hi)
        await score((await my_id(client)), event.chat_id or 0, "roll", 1)
        await event.edit(f"🎯 {value}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}choose\s+(.+)$"))
    async def choose(event):
        raw = event.pattern_match.group(1)
        options = [x.strip() for x in re.split(r"\s*\|\s*", raw) if x.strip()]
        if len(options) < 2:
            await event.reply("مثال: `.choose پیتزا | برگر | پاستا`")
            return
        await score((await my_id(client)), event.chat_id or 0, "choose", 1)
        await event.edit(f"🧠 انتخاب شد:\n\n<b>{random.choice(options)}</b>", parse_mode="html")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}blackjack$"))
    async def blackjack(event):
        ranks = [("A", 11), ("K", 10), ("Q", 10), ("J", 10)] + [(str(x), x) for x in range(2, 11)]
        def hand():
            return [random.choice(ranks), random.choice(ranks)]
        def total(cards):
            s = sum(v for _, v in cards)
            aces = sum(1 for r, _ in cards if r == "A")
            while s > 21 and aces:
                s -= 10
                aces -= 1
            return s
        player = hand()
        dealer = hand()
        pt, dt = total(player), total(dealer)
        if pt <= 21 and (dt > 21 or pt > dt):
            result = "بردی 🎉"
            pts = 3
        elif pt == dt:
            result = "مساوی 🤝"
            pts = 1
        else:
            result = "باختی 😄"
            pts = 0
        await score((await my_id(client)), event.chat_id or 0, "blackjack", pts)
        await event.edit(
            "🃏 <b>Blackjack</b>\n\n"
            f"تو: {' '.join(r for r, _ in player)} → <b>{pt}</b>\n"
            f"دیلر: {' '.join(r for r, _ in dealer)} → <b>{dt}</b>\n\n"
            f"🏁 {result}",
            parse_mode="html",
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}game\s+(?:score|stats)$"))
    async def game_score(event):
        rows = await db.fetchall(
            "SELECT game,wins,plays,points FROM game_scores WHERE owner_id=? AND chat_id=? ORDER BY points DESC, wins DESC",
            ((await my_id(client)), event.chat_id or 0),
        )
        if not rows:
            await event.reply("🏆 هنوز آماری ثبت نشده.")
            return
        lines = ["🏆 Game Stats"]
        for r in rows:
            lines.append(f"• {r['game']}: {r['wins']} برد / {r['plays']} بازی / {r['points']} امتیاز")
        await event.reply("\n".join(lines))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}leaderboard$"))
    async def leaderboard(event):
        rows = await db.fetchall(
            "SELECT owner_id,SUM(wins) wins,SUM(plays) plays,SUM(points) points FROM game_scores WHERE chat_id=? GROUP BY owner_id ORDER BY points DESC, wins DESC LIMIT 10",
            (event.chat_id or 0,),
        )
        if not rows:
            await event.reply("🏆 هنوز leaderboard خالی است.")
            return
        lines = ["🏆 Leaderboard\n"]
        for idx, r in enumerate(rows, 1):
            lines.append(f"{idx}. <code>{r['owner_id']}</code> — {r['points']} امتیاز / {r['wins']} برد")
        await event.reply("\n".join(lines), parse_mode="html")
