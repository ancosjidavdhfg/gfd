from __future__ import annotations

import os
import re
from pathlib import Path

from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
BASE = Path(__file__).resolve().parents[1]
HELP_FILE = BASE / "docs" / "HELP.txt"

SECTIONS = {
    "admin": """🛡️ Admin\n{p}ban [user]\n{p}unban [user]\n{p}kick [user]\n{p}mute [user] [duration]\n{p}unmute [user]\n{p}warn [user] [reason]\n{p}warnings [user]\n{p}unwarn [user]\n{p}del (reply)\n{p}purge <count>\n{p}pin / {p}unpin\n{p}admins""",
    "security": """🔐 Security\n{p}autoban on|off [ban|mute|delete]\n{p}whitelist add|del|list [user]\n{p}autodelete enable|disable|list [user]\n{p}filter add|del|list <text>\n{p}flood on|off <count> <seconds>\n{p}safety on|off|status\n{p}floodguard on|off|status""",
    "chat": """👥 Chat Guard\n{p}welcome on|off [template]\n{p}leave on|off\n{p}linkguard on|off [all|invite] [delete|warn|mute|ban] [duration]
{p}linkguard threshold <count> <window> <action> [duration]\n{p}rate <count> <window>\n{p}rate off""",
    "personal": """🧠 Personal\n{p}afk [reason]\n{p}back\n{p}note add|get|del|list\n{p}remind <duration> <text>\n{p}clock\n{p}profileclock on|off\n{p}bio <text>\n{p}stats\n{p}userinfo [user]\n{p}chatinfo\n{p}time <zone>""",
    "relations": """🤝 Friends / Enemies\n{p}friend add|del|on|off|list [user]\n{p}enemy add|del|on|off|list [user]\n{p}friend reply <text>\n{p}enemy reply <text>\n{p}relation reply friend|enemy <text>\n{p}relation replies [friend|enemy]\n{p}relation stats\n{p}relation cooldown friend|enemy <seconds>\n{p}relation clear friend|enemy\nبرای target می‌توانی username/ID بدهی یا روی پیامش Reply کنی. پاسخ‌ها تصادفی‌اند و cooldown دارند.""",
    "crypto": """💰 Market\nدلار / یورو / بیت کوین / تتر / سولانا\n{p}price <symbol>\n{p}market\n{p}alert <symbol> >|< <price>\n{p}alerts\n{p}alertdel <id>\n{p}hold add|set|del <coin> <qty>\n{p}portfolio""",
    "tools": """🧰 Tools\n{p}calc <expression>\n{p}msginfo (reply)\n{p}id [user/chat]\n{p}save (reply)\n{p}search <text>\n{p}readall\n{p}react <emoji> (reply)\n{p}rawchat""",
    "media": """🎞️ Media\n{p}download (reply)\n{p}sticker (reply photo)\n{p}rename <name> (reply file)\n{p}resize <width> <height> (reply photo)\n{p}watermark <text> (reply photo)""",
    "message": """🧹 Message Tools\n{p}delafter <duration> (reply)\n{p}selfdestruct <duration> <text>\n{p}cleanme [count]""",
    "games": """🎲 Games\n{p}casino <target>\n{p}casino smart 777 [max_rolls]\n{p}casino hooshmad 777 [max_rolls]\n{p}dice|dart|bowling|basket|football <target>\n{p}game cancel\n{p}game status\n{p}coin\n{p}rps rock|paper|scissors""",
    "automation": """⏰ Automation\n{p}autoreply add|del|list|on|off\n{p}watch add|del|list\n{p}autoreact <emoji> / off\n{p}notify add|del|list <chat> <keyword>\n{p}jobs\n{p}jobdel <id>""",
    "channels": """📢 Channels\n{p}comment <channel> <text>\n{p}comments <channel> <post_id>""",
}


def _build_help() -> str:
    out = ["HĀPOYI USERBOT — COMPLETE HELP", "", "Control Center: .menu", ""]
    for key, section in SECTIONS.items():
        out.append(f"===== {key.upper()} =====")
        out.append(section.format(p=PREFIX))
        out.append("")
    out.append("Notes:")
    out.append("- UserBot uses MTProto/Telethon; Assistant Bot provides the button UI.")
    out.append("- Casino smart mode is rate-limited and stops on flood/slow-mode conditions.")
    out.append("- Friend/Enemy replies use a per-user/per-chat cooldown to avoid message storms.")
    return "\n".join(out) + "\n"


def setup(client, db):
    HELP_FILE.parent.mkdir(exist_ok=True)
    HELP_FILE.write_text(_build_help(), encoding="utf-8")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}help(?:\s+(\w+))?$"))
    async def _help(event):
        section = event.pattern_match.group(1)
        if section and section.lower() in SECTIONS:
            await event.reply(SECTIONS[section.lower()].format(p=PREFIX))
            return
        await client.send_file(event.chat_id, HELP_FILE, caption="🧩 Hāpoyi UserBot — Help.txt")
        try:
            await event.delete()
        except Exception:
            pass
