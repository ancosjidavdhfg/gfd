from __future__ import annotations

import asyncio
import json
import os
import time
from core.identity import my_id
from telethon import events

from utils.formatting import parse_duration

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    async def worker():
        while True:
            try:
                if not client.is_connected():
                    await asyncio.sleep(2)
                    continue
                now = time.time()
                rows = await db.fetchall("SELECT id,owner_id,chat_id,kind,payload_json FROM jobs WHERE enabled=1 AND CAST(run_at AS REAL) <= ? ORDER BY id LIMIT 50", (now,))
                for row in rows:
                    try:
                        payload = json.loads(row["payload_json"])
                        await client.send_message(row["chat_id"], "⏰ " + payload.get("text", "Reminder"))
                    except (ConnectionError, OSError):
                        break  # offline: keep the job and retry on the next loop
                    except Exception:  # noqa: BLE001
                        pass  # permanent failure (chat gone, ...): drop the job below
                    await db.execute("UPDATE jobs SET enabled=0 WHERE id=?", (row["id"],))
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                pass
            await asyncio.sleep(2)

    asyncio.create_task(worker())

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}jobs$"))
    async def jobs(event):
        rows = await db.fetchall("SELECT id,kind,run_at,payload_json FROM jobs WHERE owner_id=? AND enabled=1 ORDER BY run_at", ((await my_id(client)),))
        await event.reply("⏰ Jobs\n" + "\n".join(f"#{r['id']} {r['kind']} {r['run_at']} {json.loads(r['payload_json']).get('text','')}" for r in rows) if rows else "⏰ Job نداری.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}jobdel\s+(\d+)$"))
    async def jobdel(event):
        await db.execute("DELETE FROM jobs WHERE id=? AND owner_id=?", (int(event.pattern_match.group(1)),(await my_id(client))))
        await event.reply("✅ Job حذف شد.")
