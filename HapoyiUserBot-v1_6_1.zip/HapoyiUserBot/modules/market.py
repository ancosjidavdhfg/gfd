from __future__ import annotations

import os
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events

from providers.crypto import MarketProvider
from providers.fx import FXProvider
from utils.formatting import fmt_money

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
DEFAULTS = ["BTC", "ETH", "SOL", "USDT", "TON"]
TRIGGERS = {
    "دلار": "USD", "usd": "USD", "یورو": "EUR", "eur": "EUR",
    "بیت کوین": "BTC", "بیتکوین": "BTC", "bitcoin": "BTC", "btc": "BTC",
    "اتریوم": "ETH", "ethereum": "ETH", "eth": "ETH",
    "سولانا": "SOL", "solana": "SOL", "sol": "SOL",
    "تتر": "USDT", "usdt": "USDT", "تون": "TON", "ton": "TON",
}


def setup(client, db):
    provider = MarketProvider()
    fx = FXProvider(cache_seconds=60)

    async def render(symbol: str) -> str:
        if symbol == "USD":
            irr = await fx.usd_to_irr()
            toman = irr / 10.0
            return f"💵 دلار / USD\n🇺🇸 1 USD\n🇮🇷 {fmt_money(toman, 0)} تومان\n🕐 {datetime.now(ZoneInfo('Asia/Tehran')).strftime('%Y-%m-%d %H:%M')}\n📡 FX reference"
        if symbol == "EUR":
            return "💶 یورو / EUR\nقیمت یورو برای Toman نیازمند provider مخصوص بازار ایران است.\n🕐 " + datetime.now(ZoneInfo("Asia/Tehran")).strftime("%Y-%m-%d %H:%M")
        q = await provider.quote(symbol)
        change = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
        toman = f"{fmt_money(q.toman, 0)} تومان" if q.toman is not None else "در دسترس نیست"
        return (
            f"🪙 {q.symbol}\n\n"
            f"💵 USD: ${fmt_money(q.usd, 6 if q.usd < 1 else 2)}\n"
            f"🇮🇷 Toman: {toman}\n"
            f"📈 24H: {change}\n"
            f"🕐 {datetime.now(ZoneInfo('Asia/Tehran')).strftime('%Y-%m-%d %H:%M')}\n"
            f"📡 {q.source}"
        )

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}(?:price|p)\s+(.+)$"))
    async def price_cmd(event):
        raw = event.pattern_match.group(1).strip()
        symbol = TRIGGERS.get(raw.lower(), raw.upper())
        try:
            await event.edit(await render(symbol))
        except Exception as exc:
            await event.edit(f"❌ دریافت قیمت ناموفق بود: {exc.__class__.__name__}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}market$"))
    async def market_cmd(event):
        lines = ["📊 Market Dashboard", ""]
        for symbol in DEFAULTS:
            try:
                q = await provider.quote(symbol)
                toman = fmt_money(q.toman, 0) if q.toman is not None else "—"
                ch = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
                lines.append(f"{q.symbol}: ${fmt_money(q.usd, 2)} | {toman} تومان | {ch}")
            except Exception as exc:
                lines.append(f"{symbol}: ❌ {exc.__class__.__name__}")
        lines.append("\n🕐 " + datetime.now(ZoneInfo("Asia/Tehran")).strftime("%Y-%m-%d %H:%M"))
        await event.edit("\n".join(lines))

    @client.on(events.NewMessage)
    async def natural_price(event):
        if not event.out or not event.raw_text or event.raw_text.startswith(PREFIX):
            return
        text = event.raw_text.strip().lower()
        if text not in TRIGGERS:
            return
        # Edit only the user's own trigger message as requested.
        try:
            await event.edit(await render(TRIGGERS[text]))
        except Exception:
            pass
