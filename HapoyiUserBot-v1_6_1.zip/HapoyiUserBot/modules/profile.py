from __future__ import annotations

import asyncio
import os
from datetime import datetime
from zoneinfo import ZoneInfo
from telethon import events
from telethon.tl.functions.account import UpdateProfileRequest

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    task: asyncio.Task | None = None

    async def clock_loop():
        while True:
            enabled = await db.get_kv("profile_clock", False)
            if enabled:
                zone = os.getenv("TIMEZONE", "Asia/Tehran")
                now = datetime.now(ZoneInfo(zone))
                text = f"🕐 {now.strftime('%H:%M')} • Hāpoyi"
                try:
                    await client(UpdateProfileRequest(about=text))
                except Exception:
                    pass
            await asyncio.sleep(max(10, 60 - datetime.now().second))

    nonlocal_task = {"task": None}

    async def ensure_task():
        if nonlocal_task["task"] is None or nonlocal_task["task"].done():
            nonlocal_task["task"] = asyncio.create_task(clock_loop())

    asyncio.create_task(ensure_task())

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}profileclock\s+(on|off)$"))
    async def profile_clock(event):
        enabled = event.pattern_match.group(1) == "on"
        await db.set_kv("profile_clock", enabled)
        await event.reply("🕐 Profile Clock " + ("روشن شد." if enabled else "خاموش شد."))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}bio\s+(.+)$"))
    async def bio(event):
        await client(UpdateProfileRequest(about=event.pattern_match.group(1)[:70]))
        await event.reply("✅ Bio تغییر کرد.")
