from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from core.identity import my_id
from telethon import events

from providers.crypto import MarketProvider
from utils.formatting import fmt_money

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."


def setup(client, db):
    provider = MarketProvider(cache_seconds=20)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}hold\s+(add|set|del)\s+(\S+)(?:\s+([0-9]*\.?[0-9]+))?$"))
    async def hold(event):
        action, symbol, amount = event.pattern_match.groups()
        coin = provider.resolve(symbol)
        if not coin:
            return await event.reply("❌ ارز پشتیبانی نمی‌شود.")
        user = (await my_id(client))
        if action == "del":
            await db.execute("DELETE FROM portfolio WHERE owner_id=? AND symbol=?", (user, coin))
            return await event.reply(f"✅ {symbol.upper()} از پرتفوی حذف شد.")
        if amount is None:
            return await event.reply("❌ مقدار را بده؛ مثال: .hold add btc 0.1")
        qty = float(amount)
        if qty <= 0:
            return await event.reply("❌ مقدار باید مثبت باشد.")
        await db.execute("INSERT INTO portfolio(owner_id,symbol,quantity,updated_at) VALUES(?,?,?,?) ON CONFLICT(owner_id,symbol) DO UPDATE SET quantity=excluded.quantity,updated_at=excluded.updated_at", (user, coin, qty, datetime.now(timezone.utc).isoformat()))
        await event.reply(f"✅ {symbol.upper()} = {qty:g} ذخیره شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}portfolio$"))
    async def portfolio(event):
        rows = await db.fetchall("SELECT symbol,quantity FROM portfolio WHERE owner_id=? ORDER BY symbol", ((await my_id(client)),))
        if not rows:
            return await event.reply("💼 پرتفوی خالی است.\nمثال: .hold add btc 0.1")
        total_usd = 0.0; lines = ["💼 Portfolio", ""]
        for row in rows:
            try:
                q = await provider.quote(row["symbol"])
                value = float(row["quantity"]) * q.usd
                total_usd += value
                toman = float(row["quantity"]) * q.toman if q.toman is not None else None
                lines.append(f"{q.symbol}: {float(row['quantity']):g} × ${fmt_money(q.usd, 4)} = ${fmt_money(value, 2)}" + (f" | {fmt_money(toman, 0)} تومان" if toman is not None else ""))
            except Exception:
                lines.append(f"{row['symbol'].upper()}: {row['quantity']} | ❌ quote")
        lines.extend(["", f"💵 Total USD: ${fmt_money(total_usd, 2)}", f"🕐 {datetime.now(ZoneInfo('Asia/Tehran')).strftime('%Y-%m-%d %H:%M')} "])
        await event.reply("\n".join(lines))
