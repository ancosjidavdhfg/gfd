from __future__ import annotations

import os
import time
import aiohttp


class FXProvider:
    def __init__(self, cache_seconds: int = 60):
        self.cache_seconds = cache_seconds
        self.cache: tuple[float, float] | None = None

    async def usd_to_irr(self) -> float:
        now = time.monotonic()
        if self.cache and now - self.cache[0] < self.cache_seconds:
            return self.cache[1]
        custom = os.getenv("IRAN_FX_URL", "").strip()
        async with aiohttp.ClientSession() as session:
            if custom:
                headers = {}
                key = os.getenv("IRAN_FX_KEY", "").strip()
                if key:
                    headers["Authorization"] = f"Bearer {key}"
                async with session.get(custom, headers=headers, timeout=10) as r:
                    data = await r.json()
                value = self._extract(data)
            else:
                async with session.get("https://open.er-api.com/v6/latest/USD", timeout=10) as r:
                    data = await r.json()
                value = float(data["rates"]["IRR"])
        self.cache = (now, value)
        return value

    @staticmethod
    def _extract(data: dict) -> float:
        candidates = [
            data.get("USD_IRR"), data.get("usd_irr"), data.get("rate"),
            (data.get("rates") or {}).get("IRR"), (data.get("rates") or {}).get("irr"),
        ]
        for value in candidates:
            if value is not None:
                return float(value)
        raise ValueError("IRR rate not found in custom FX response")
