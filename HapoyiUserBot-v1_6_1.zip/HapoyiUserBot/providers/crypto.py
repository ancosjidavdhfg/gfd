from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass
from typing import Any

import aiohttp

COINGECKO = {
    "btc": "bitcoin", "bitcoin": "bitcoin", "بیت کوین": "bitcoin", "بیتکوین": "bitcoin",
    "eth": "ethereum", "ethereum": "ethereum", "اتریوم": "ethereum",
    "sol": "solana", "solana": "solana", "سولانا": "solana",
    "usdt": "tether", "tether": "tether", "تتر": "tether",
    "bnb": "binancecoin", "bnb": "binancecoin", "xrp": "ripple", "doge": "dogecoin",
    "ton": "the-open-network", "toncoin": "the-open-network", "تون": "the-open-network",
    "ada": "cardano", "cardano": "cardano", "trx": "tron", "ترون": "tron",
    "avax": "avalanche-2", "dot": "polkadot", "link": "chainlink",
}
FA_SYMBOL = {"bitcoin": "BTC", "ethereum": "ETH", "solana": "SOL", "tether": "USDT", "the-open-network": "TON"}


@dataclass
class Quote:
    symbol: str
    name: str
    usd: float
    toman: float | None
    change_24h: float | None
    source: str
    at: float


class MarketProvider:
    def __init__(self, cache_seconds: int = 20):
        self.cache_seconds = cache_seconds
        self.cache: dict[str, tuple[float, Quote]] = {}
        self._lock = asyncio.Lock()

    def resolve(self, raw: str) -> str | None:
        key = raw.strip().lower().replace("₿", "btc")
        return COINGECKO.get(key)

    async def _get_json(self, session: aiohttp.ClientSession, url: str, *, params: dict[str, Any] | None = None) -> dict[str, Any]:
        headers = {"User-Agent": "HapoyiUserBot/1.0"}
        api_key = os.getenv("COINGECKO_API_KEY", "").strip()
        if api_key and "coingecko" in url:
            headers["x-cg-demo-api-key"] = api_key
        async with session.get(url, params=params, headers=headers, timeout=aiohttp.ClientTimeout(total=12)) as r:
            r.raise_for_status()
            return await r.json()

    async def quote(self, raw: str) -> Quote:
        coin_id = self.resolve(raw)
        if not coin_id:
            raise ValueError("ارز ناشناخته است")
        async with self._lock:
            cached = self.cache.get(coin_id)
            if cached and time.monotonic() - cached[0] < self.cache_seconds:
                return cached[1]
            async with aiohttp.ClientSession() as session:
                cg = await self._get_json(
                    session,
                    "https://api.coingecko.com/api/v3/simple/price",
                    params={"ids": coin_id, "vs_currencies": "usd", "include_24hr_change": "true"},
                )
                item = cg.get(coin_id) or {}
                usd = float(item["usd"])
                change = item.get("usd_24h_change")
                toman = await self._nobitex_toman(session, FA_SYMBOL.get(coin_id))
                q = Quote(self.display_symbol(coin_id), coin_id, usd, toman, float(change) if change is not None else None, "CoinGecko + Nobitex", time.time())
                self.cache[coin_id] = (time.monotonic(), q)
                return q

    async def _nobitex_toman(self, session: aiohttp.ClientSession, symbol: str | None) -> float | None:
        if not symbol:
            return None
        url = "https://api.nobitex.ir/market/stats"
        try:
            data = await self._get_json(session, url, params={"srcCurrency": symbol.lower(), "dstCurrency": "rls"})
            stats = (data.get("stats") or {}).get(f"{symbol.lower()}-rls")
            if stats and stats.get("latest") is not None:
                return float(stats["latest"]) / 10.0
        except Exception:
            return None
        return None

    @staticmethod
    def display_symbol(coin_id: str) -> str:
        return FA_SYMBOL.get(coin_id, coin_id.upper())

    async def market(self, symbols: list[str]) -> list[Quote]:
        quotes = []
        for symbol in symbols:
            try:
                quotes.append(await self.quote(symbol))
            except Exception:
                continue
        return quotes
