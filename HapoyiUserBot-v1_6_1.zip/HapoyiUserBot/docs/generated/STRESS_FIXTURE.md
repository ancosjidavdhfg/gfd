# Synthetic SQLite Stress Fixture

`tests/fixtures/stress.sqlite` contains synthetic, non-user data for validating local SQLite throughput and backup/restore workflows. It contains 75,000 generated message-like rows. No Telegram account, chat, phone number, API credential, session or real conversation is embedded in the fixture.

The fixture is intentionally part of the repository because Hāpoyi is expected to keep a persistent local database for long-running automation. It can be removed from a production deployment after tests if disk size matters.
