# Telegram Capability Matrix

The matrix below is a planning and implementation map, not a claim that every Telegram API method is implemented.

| Area | Current state | Hāpoyi module | Notes |
|---|---|---|---|
| MTProto client | Implemented | core/client.py | Telethon user account |
| New message events | Implemented | many modules | Central Telegram update stream |
| Interactive Control Center | Implemented | modules/ui.py | Assistant Bot renders inline callback buttons; UserBot remains the execution account |
| Chat actions | Implemented | modules/security.py | AutoBan joins/adds |
| Ban/unban/kick | Implemented | modules/admin.py | Requires permission |
| Mute/unmute | Implemented | modules/admin.py | Uses channel ban rights |
| Delete/purge | Implemented | modules/admin.py | Requires Delete Messages in groups |
| Pin/unpin | Implemented | modules/admin.py | Requires Pin Messages in groups |
| Warnings | Implemented | modules/moderation.py | Persistent SQLite counter |
| AutoDelete | Implemented | modules/security.py | Activation timestamp enforced |
| AutoBan | Implemented | modules/security.py | Per-chat + whitelist |
| Filters | Implemented | modules/security.py | Keyword delete |
| Flood guard | Implemented | modules/moderation.py | In-memory counters |
| AFK | Implemented | modules/personal.py | Reply to inbound messages |
| Notes | Implemented | modules/personal.py | SQLite |
| Reminder | Implemented | modules/personal.py + scheduler.py | Persistent job |
| Message search | Implemented | modules/tools.py | Telegram server-side search |
| Message metadata | Implemented | modules/tools.py | Message ID, sender, media, views |
| Saved Messages copy | Implemented | modules/tools.py | Local forwarding |
| Reactions | Implemented | modules/tools.py | Reply target |
| AutoReact | Implemented | modules/automation.py | Chat-local |
| AutoReply | Implemented | modules/automation.py | Chat-local |
| Watch keywords | Implemented | modules/automation.py | Owner notifications |
| Channel comments | Implemented | modules/channel.py | Last post or chosen post |
| Profile clock | Implemented | modules/profile.py | Updates bio periodically |
| Crypto quotes | Implemented | modules/market.py | Provider-based |
| Price alerts | Implemented | modules/alerts.py | USD thresholds |
| Dice games | Implemented | modules/games.py | Bounded loops |
| Media download | Implemented | modules/media.py | Telegram media |
| Image resize | Implemented | modules/media.py | Pillow |
| Watermark | Implemented | modules/media.py | Pillow |
| WebP conversion | Implemented | modules/media.py | Pillow |
| Stories | Roadmap | - | Account/API capability dependent |
| Gifts/Stars | Roadmap | - | Requires additional account/API workflows |
| Business features | Roadmap | - | Account type and raw API details vary |
| Forum topic management | Roadmap | - | Raw API handlers can be added separately |
| Giveaways | Roadmap | - | Depends on Telegram feature surface |
| Full AI assistant | Roadmap | - | Provider contract must be selected by user |
| Translation | Roadmap | - | Requires explicit translation provider |
| Weather | Roadmap | - | Requires explicit weather provider |
| Advanced video conversion | Roadmap | - | ffmpeg integration can be added |
| Plugin marketplace | Not planned by default | - | Avoided for security/auditability |
