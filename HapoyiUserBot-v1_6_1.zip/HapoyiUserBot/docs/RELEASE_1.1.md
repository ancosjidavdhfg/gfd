# Hāpoyi UserBot 1.1.0 — Night Market

This update adds practical chat lifecycle controls and a personal market layer.

## New modules
- `chat_features`: Welcome, leave notices, LinkGuard, Rate Guard.
- `message_lifecycle`: delayed deletion, self-destruct messages, clean own messages.
- `portfolio`: persistent crypto holdings and live valuation.
- `notify`: keyword notifications from watched chats.

## Validation performed
- Python `compileall` across the source tree: pass.
- `scripts/smoke_test.py`: pass.
- `security/audit_source.py`: pass; no `eval`/`exec` detected.
- Outbound URLs are listed by the source audit.

A live Telegram account test still depends on installing the pinned dependencies and using the user's own Telegram credentials on the target machine.
