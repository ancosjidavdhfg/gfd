# Hāpoyi Control Center UI

## چرا Assistant Bot؟

Telegram inline callback buttons are a Bot-side feature. The main account stays a normal MTProto UserBot and keeps the privileged actions; the companion Assistant Bot renders the interactive menu.

## Setup

Create a Bot with `@BotFather`, then add its token to `.env`:

```env
BOT_TOKEN=123456:replace_me
UI_ENABLED=true
HAPOYI_BOT_SESSION=/root/HapoyiUserBot/data/hapoyi_ui_bot
```

The UserBot owner ID is discovered at startup and callbacks are accepted only from that account.

For a group menu, the Assistant Bot must be a member of the group and be able to send messages.

## Commands

- `.menu` or `.panel` opens the Control Center.
- Category buttons show the actual command inventory already implemented by the project.
- Market and quick-price buttons fetch live data and render it inside the button-driven panel.
- Back/Home navigation never creates a new message; the existing panel message is edited in place.

No remote plugin loader, hidden telemetry, or arbitrary callback execution is used by this UI module.
