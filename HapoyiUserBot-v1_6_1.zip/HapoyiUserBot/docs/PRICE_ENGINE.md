# Price Engine Design

## User-facing behavior

The fast path is intentionally simple. A user can type a natural trigger as an outgoing message:

- `دلار`
- `بیت کوین`
- `تتر`
- `سولانا`
- `اتریوم`
- `TON`

The bot intercepts the user's own outgoing message and edits it into a structured quote.

For a supported crypto asset the format includes:

1. Asset symbol.
2. USD price.
3. Toman price if the local market endpoint resolves the asset.
4. 24-hour percentage change.
5. Tehran-local timestamp to the minute.
6. Data-source label.

## Provider separation

The global price provider is CoinGecko. The local exchange layer uses Nobitex public market statistics when possible. The code intentionally treats the two values as different data products: a global USD quote and an Iran-market local quote.

## Failure behavior

If the global provider fails, the message is edited to a compact error rather than leaving stale-looking data. If the local quote is missing, the USD value remains useful and Toman is shown as unavailable.

## Cache policy

The provider caches a quote briefly to limit unnecessary repeated requests. This is especially important because Telegram clients can trigger several events around a single user action and external providers have rate limits.

## Adding an asset

Add the asset alias to `providers/crypto.py`. If the asset has a direct Nobitex market pair, add the market symbol to `FA_SYMBOL`. If it does not, the global USD quote still works.

## Local FX replacement

Set `IRAN_FX_URL` and optionally `IRAN_FX_KEY` when an alternate FX provider is preferred. The generic FX provider expects a JSON field such as `USD_IRR` or `rates.IRR`.

## Accuracy language

A UserBot should show a timestamp and source because exchange prices are changing values. A display price is not a promise of execution price, and a local exchange quote may differ from other Iranian exchanges.
