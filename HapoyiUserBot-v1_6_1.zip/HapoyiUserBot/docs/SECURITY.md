# Security Model

## Secrets

Never put the following in source control:

- Telegram API hash
- Telegram session string/session file
- Bot tokens
- Provider API keys
- Private cookies

`.env.example` contains placeholders only.

## Session boundary

Telethon stores the authorization key in its session. That session can authenticate the account and must be treated like a password. The project does not log the session or include it in the ZIP.

## Outbound HTTP

Expected provider URLs are visible in source and reported by `security/audit_source.py`. This is intentionally different from a generic plugin loader: the project should have a small, inspectable outbound surface.

## Dynamic execution

The source audit rejects direct `eval` and `exec` calls in project code. The calculator uses AST inspection with an explicit operator allowlist.

## Dependency boundary

A source audit cannot prove that PyPI packages are safe. Pinning versions reduces unexpected upgrades; review changelogs and hashes when upgrading dependencies.

## Telegram privileges

Admin commands only attempt actions after checking the account's Telegram permissions. A lack of permission returns a human-readable message rather than blindly retrying.

## Long-running loops

Automations must have bounds, delays and cancellation. This matters for both Telegram FloodWait behavior and external provider rate limits.
