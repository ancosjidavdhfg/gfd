# Hāpoyi UserBot 1.4.0 — GameForge

## Game engine

- Full Telegram 🎰 slot decoder for values 1..64.
- Exact combination targeting: `lemon lemon lemon`, `seven lemon seven`, etc.
- Count targeting: `2 lemon 1 seven`.
- Pattern targeting: `jackpot`, `pair`, `different`, `any-seven`, `center-seven`, `left-seven`, `right-seven`, `no-seven`.
- Numeric targeting: any value 1..64 and `777` as alias for value 64.
- Smart mode with adaptive delay and hard stop on flood/slow-mode conditions.
- `.casino all` produces a complete lookup file; `.casino explain N` decodes an outcome.

## Other games

Telegram dice-family runners plus local games: coin toss, RPS, roulette, 8-ball, blackjack, numeric roll and chooser.

## Persistence

Game scores are persisted in SQLite with per-player/per-chat/per-game wins, plays and points. `.game score` and `.leaderboard` expose the results.

## Safety

The engine deliberately does not implement anti-detection or spam-evasion. It uses the existing SafetyGuard/FloodGuard and stops or backs off on Telegram rate-limit errors.
