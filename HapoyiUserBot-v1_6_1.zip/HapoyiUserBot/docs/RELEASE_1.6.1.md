# Hāpoyi UserBot v1.6.1 — Hardening / Bug-fix release

## Fixed
- **Group moderation never worked** (`.ban .mute .kick .unban .unmute .del .purge .pin .unpin .admins`):
  `modules/admin.py` crashed at import (`ChatBannedRights()` needs `until_date`), so the whole module was
  silently not loaded. Same wrong constructor was used in `warn`, `autoban`, `linkguard`.
- **Permission check was wrong**: Telethon's `ParticipantPermissions` has no `admin_rights`; every admin
  who was not the creator was told "no access". Now the real properties (`ban_users`, ...) are used.
- **Anyone could drive your account** (`.mute`, `.ban`, `.casino`, `.purge`...): command filter was
  `not e.out or e.out` (always true). All command handlers are now `outgoing=True`, plus a central guard
  (`core/guard.py`) that refuses a command event that was not sent by your own account.
- Every command now answers: `✅ ... با موفقیت` or `❌ ... نشد: <reason>` (also for Telegram RPC errors).
- **AFK**: announces only in *private chats*, **once per person per AFK session**, never to bots /
  Telegram service (777000) / yourself, and the real name is used (was hard-coded "امیر"). A failed
  send does not burn the person's single notice. `.afk` starts a new session, `.back` ends it.
- `.mute 10s` used to become a **permanent** mute (Telegram treats < 30s as forever) -> refused.
- `.mute 10m` as a reply no longer treats `10m` as a username.
- In forum groups an implicit "reply to topic" no longer mutes/bans the topic creator.
- `.react` / AutoReact crashed (`Message.react` does not exist in Telethon 1.45) -> raw `SendReactionRequest`.
- AutoReply answered **your own** messages; Filter deleted your own / admins' messages.
- `.autoreact off` ran both handlers; `.linkguard status|threshold` also triggered the generic handler.
- `.alert` always failed (`created_at NOT NULL` missing); alert id was racy.
- Reminders due while the bot was offline were lost; scheduler now waits for the connection.
- `.cleanme` wrongly required admin rights to delete *your own* messages.
- UI panel buttons were rejected unless `HAPOYI_OWNER_ID` was set; now defaults to the logged-in account.
- Hard-coded `PREFIX = "."` in games; extra `get_me()` network calls on every incoming message.

## Added
- `core/guard.py` (owner-only + exception reporting), `core/actions.py`, `core/identity.py`, `utils/rights.py`.
- `.purge` with reply deletes from the replied message to the command; `.unpin` with reply / `.unpin all`.
- Table `afk_notified`, `Database.insert()`.
- `tests/test_regressions.py` (37 tests in the suite).
