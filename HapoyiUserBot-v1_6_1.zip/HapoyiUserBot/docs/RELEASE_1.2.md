# Hāpoyi UserBot 1.2.0 — Control Center

## UI

- Added `.menu` and `.panel`.
- Added Assistant Bot-based inline callback UI.
- Added home dashboard, category navigation, back/home controls.
- Added live Market Dashboard inside the UI.
- Added quick price buttons for USD/BTC/ETH/SOL/USDT/TON.
- Added owner-only callback authorization.
- Added graceful fallback when no `BOT_TOKEN` is configured.
- Added robust fallback when the Assistant Bot token is invalid or the bot cannot start.
- Added group guidance: Assistant Bot must be a member and able to send messages.

## Architecture

The privileged account stays a normal Telethon UserBot. The Assistant Bot only renders the interactive control surface and receives callback clicks; actual user-account behavior remains on the UserBot side.

## Configuration

```env
BOT_TOKEN=
UI_ENABLED=true
HAPOYI_BOT_SESSION=/root/HapoyiUserBot/data/hapoyi_ui_bot
```

The owner ID is discovered automatically at UserBot startup.
