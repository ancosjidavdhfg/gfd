from pathlib import Path
import sqlite3


def test_stress_fixture_shape():
    p = Path(__file__).parent / 'fixtures' / 'stress.sqlite'
    assert p.exists()
    con = sqlite3.connect(p)
    count = con.execute('select count(*) from benchmark_messages').fetchone()[0]
    assert count == 75000
    con.close()
