from __future__ import annotations

import ast
import re
from collections import Counter
from pathlib import Path


def _load_pure_functions():
    source = Path(__file__).parents[1].joinpath("modules", "games.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    wanted_assigns = {"SLOT_SYMBOLS", "SLOT_CANONICAL", "SYMBOL_ALIASES", "NUMBER_WORDS"}
    wanted_funcs = {
        "slot_combo", "slot_value", "slot_display", "all_slot_values",
        "slot_is_triple", "slot_is_pair", "slot_matches", "parse_slot_target",
    }
    body = []
    for node in tree.body:
        if isinstance(node, ast.Assign):
            names = {x.id for x in node.targets if isinstance(x, ast.Name)}
            if names & wanted_assigns:
                body.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in wanted_funcs:
            body.append(node)
    ns = {"re": re, "Counter": Counter}
    exec(compile(ast.Module(body=body, type_ignores=[]), "games_pure", "exec"), ns)
    return ns


N = _load_pure_functions()


def test_all_64_values_are_unique_and_roundtrip():
    combos = [N["slot_combo"](i) for i in range(1, 65)]
    assert len(set(combos)) == 64
    for i, combo in enumerate(combos, 1):
        assert N["slot_value"](combo) == i


def test_known_telegram_outcomes():
    assert N["slot_combo"](1) == ("bar", "bar", "bar")
    assert N["slot_combo"](22) == ("grape", "grape", "grape")
    assert N["slot_combo"](43) == ("lemon", "lemon", "lemon")
    assert N["slot_combo"](64) == ("seven", "seven", "seven")


def test_exact_and_count_targets():
    mode, target, _ = N["parse_slot_target"]("lemon seven lemon")
    assert mode == "exact" and target == ("lemon", "seven", "lemon")
    mode, target, _ = N["parse_slot_target"]("2 lemon 1 seven")
    assert mode == "counts" and target == Counter({"lemon": 2, "seven": 1})


def test_pattern_targets():
    mode, target, _ = N["parse_slot_target"]("center-seven")
    assert mode == "predicate" and target == "center-seven"
    assert N["slot_matches"](("lemon", "seven", "bar"), "center-seven")
    assert N["slot_matches"](("lemon", "seven", "bar"), "any-seven")
    assert not N["slot_matches"](("lemon", "bar", "bar"), "center-seven")
    assert N["slot_matches"](("lemon", "bar", "seven"), "pair") is False
    assert N["slot_matches"](("lemon", "bar", "bar"), "pair") is True


def test_every_value_has_three_symbols():
    for value in range(1, 65):
        combo = N["slot_combo"](value)
        assert len(combo) == 3
        assert all(x in N["SLOT_CANONICAL"] for x in combo)
