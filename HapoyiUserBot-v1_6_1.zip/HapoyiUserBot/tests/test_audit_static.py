from __future__ import annotations

import ast
from pathlib import Path


def test_audit_module_structure():
    source = Path("modules/audit_logger.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    names = {node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    assert {"setup", "_format_new", "_format_edit", "_format_delete", "_queue_log"} <= names
    assert "AUDIT_BOT_TOKEN" in source
    assert "AUDIT_BATCH_SECONDS" in source
    assert "events.MessageEdited" in source
    assert "events.NewMessage" in source
    assert "MessageDeleted" in source


def test_audit_is_opt_in():
    source = Path("modules/audit_logger.py").read_text(encoding="utf-8")
    assert "FROM audit_configs" in source or "from audit_configs" in source.lower()
    assert "WHERE chat_id=? AND enabled=1" in source
