from utils.linkguard import LinkCounter, contains_link


def test_contains_links_all_and_invite():
    assert contains_link('visit https://example.com now')
    assert contains_link('join https://t.me/+abcdef', 'invite')
    assert not contains_link('hello friend', 'all')
    assert not contains_link('https://example.com', 'invite')


def test_rolling_link_counter():
    c = LinkCounter()
    a = c.add(-100, 42, 60)
    b = c.add(-100, 42, 60)
    assert a.count == 1
    assert b.count == 2
    c.reset(-100, 42)
    assert c.add(-100, 42, 60).count == 1
