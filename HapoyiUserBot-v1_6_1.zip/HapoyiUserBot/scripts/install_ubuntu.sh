#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/root/HapoyiUserBot}"
cd "$(dirname "$0")/.."

echo "[1/6] Installing OS packages..."
sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-pip ffmpeg sqlite3

echo "[2/6] Creating virtual environment..."
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/python" -m pip install -U pip wheel

echo "[3/6] Installing Python dependencies..."
"$APP_DIR/venv/bin/python" -m pip install -r requirements.txt

echo "[4/6] Creating config..."
if [[ ! -f "$APP_DIR/.env" ]]; then cp .env.example "$APP_DIR/.env"; fi
mkdir -p "$APP_DIR/data/media"

echo "[5/6] Installing systemd unit..."
sed "s#/root/HapoyiUserBot#$APP_DIR#g" systemd/hapoyi-userbot.service | sudo tee /etc/systemd/system/hapoyi-userbot.service >/dev/null
sudo systemctl daemon-reload

echo "[6/6] Syntax check..."
"$APP_DIR/venv/bin/python" scripts/smoke_test.py

echo
printf 'Install complete. Edit %s/.env then run:\n' "$APP_DIR"
echo "  sudo systemctl enable --now hapoyi-userbot"
