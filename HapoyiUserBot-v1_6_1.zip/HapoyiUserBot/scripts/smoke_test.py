from __future__ import annotations

import ast
import compileall
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

errors: list[str] = []
for path in ROOT.rglob("*.py"):
    if any(part in {"venv", ".git", "__pycache__"} for part in path.parts):
        continue
    try:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except Exception as exc:
        errors.append(f"{path}: {exc}")

if not compileall.compile_dir(ROOT, quiet=1):
    errors.append("compileall reported an error")

if errors:
    print("SMOKE TEST FAILED")
    print("\n".join(errors))
    raise SystemExit(1)

print("SMOKE TEST OK")
